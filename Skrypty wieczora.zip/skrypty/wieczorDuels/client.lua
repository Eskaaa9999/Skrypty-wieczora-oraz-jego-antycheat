ESX = exports['es_extended']:getSharedObject()
local DuelsZones = {}
local isInFight = false
local isStarting = false
local startWalkowers = false
local block = false
local HasAlreadyEnteredMarker = false
local CurrentZone = nil
local LastZone = nil
local isInKolejka = false

RegisterNetEvent("wieczorDuels:KolejkaState")
AddEventHandler("wieczorDuels:KolejkaState", function(state)
    isInKolejka = state
end)

function StartLiczenie(name, id)
    ESX.Scaleform.ShowFreemodeMessage('~r~D~g~U~b~E~p~L', "Pojedynek z ~b~"..name.." ~q~["..id.."] ~w~rozpoczyna się!", 3)
    ESX.Scaleform.ShowFreemodeMessage('~r~D~g~U~b~E~p~L', "Rozpoczyna się za ~o~5", 1)
    ESX.Scaleform.ShowFreemodeMessage('~r~D~g~U~b~E~p~L', "Rozpoczyna się za ~o~4", 1)
    ESX.Scaleform.ShowFreemodeMessage('~r~D~g~U~b~E~p~L', "Rozpoczyna się za ~o~3", 1)
    ESX.Scaleform.ShowFreemodeMessage('~r~D~g~U~b~E~p~L', "Rozpoczyna się za ~o~2", 1)
    ESX.Scaleform.ShowFreemodeMessage('~r~D~g~U~b~E~p~L', "Rozpoczyna się za ~o~1", 1)
    ESX.ShowNotification("Jeżeli chcesz opuścić arenę wpisz /opuscwalke ;>")
    startWalkowers = true
    isStarting = false
end

function DisableActions()
    DisableControlAction(2, 24, true)
    DisableControlAction(2, 257, true)
    DisableControlAction(2, 25, true)
    DisableControlAction(2, 263, true)
    DisableControlAction(2, 37, true)
    DisableControlAction(2, 40, true)
    DisableControlAction(2, 39, true)
    DisableControlAction(0, 37, true)
    DisableControlAction(0, 257, true)
    DisableControlAction(0, 140, true)
    DisableControlAction(0, 141, true)
    DisableControlAction(0, 142, true)
    DisableControlAction(0, 143, true)
    DisablePlayerFiring(PlayerPedId(), true)
end

RegisterNetEvent("wieczorDuels:Start")
AddEventHandler("wieczorDuels:Start", function(Arena, kordytwojejmordy, name, przeciwnik)
    isStarting = true
    isInFight = true
    SetEntityCoords(PlayerPedId(), kordytwojejmordy)
    StartLiczenie(name, przeciwnik)
end)

RegisterNetEvent("wieczorDuels:Stop")
AddEventHandler("wieczorDuels:Stop", function()
    isInFight = false
    isInKolejka = false
end)

RegisterNetEvent("wieczorDuels:Win")
AddEventHandler("wieczorDuels:Win", function(iswalkower, name, id)
    if iswalkower then
        ESX.Scaleform.ShowFreemodeMessage('~y~ZWYCIĘSTWO', "Wygrałeś pojedynek z ~q~"..name.."~w~ ["..id.."] ~o~WALKOWEREM!", 5)
    else
        ESX.Scaleform.ShowFreemodeMessage('~y~ZWYCIĘSTWO', "Wygrałeś pojedynek z ~q~"..name.."~w~ ["..id.."]!", 5)
    end
    TriggerServerEvent("duels:event1337")
end)

function Draw3DText(x,y,z,textInput,fontId,scaleX,scaleY)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    local dist = GetDistanceBetweenCoords(px,py,pz, x,y,z, 1)    
    local scale = (1/dist)*20
    local fov = (1/GetGameplayCamFov())*100
    local scale = scale*fov   
    SetTextScale(scaleX*scale, scaleY*scale)
    SetTextFont(fontId)
    SetTextProportional(1)
    SetTextColour(200, 200, 200, 255)
    SetTextDropshadow(31, 31, 31, 0.5, 255)
    SetTextEdge(2, 0, 0, 0, 150)
    SetTextDropShadow()
    SetTextOutline()
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(textInput)
    SetDrawOrigin(x,y,z+2, 0)
    DrawText(0.0, 0.0)
    ClearDrawOrigin()
end

CreateThread(function()
	while true do
		Citizen.Wait(0)
		local coords, sleep = GetEntityCoords(PlayerPedId()), true
		for k,v in pairs(Config.Zones) do
			if (#(coords - vec3(v.zone_coords.x, v.zone_coords.y, v.zone_coords.z)) < 25.0) then
				sleep = false
				ESX.DrawBigMarker(vec3(v.zone_coords.x, v.zone_coords.y, v.zone_coords.z))
                Draw3DText(v.zone_coords.x, v.zone_coords.y, v.zone_coords.z, "~w~DUELE ~r~"..v.name, 4, 0.1, 0.1)
			end
		end
		if sleep then
			Citizen.Wait(750)
		end
	end
end)

CreateThread(function()
	while true do
		Citizen.Wait(0)
		local coords, sleep = GetEntityCoords(PlayerPedId()), true
		local isInMarker  = false
        local zone = ""
		for k,v in pairs(Config.Zones) do
			if #(coords - vec3(v.zone_coords.x, v.zone_coords.y, v.zone_coords.z)) < 3.5 then
				sleep = false
				isInMarker = true
                zone = v.name
			end
		end
		if isInMarker and not HasAlreadyEnteredMarker then
			HasAlreadyEnteredMarker = true
            CurrentZone = zone
            LastZone = zone
		end
		if not isInMarker and HasAlreadyEnteredMarker then
            if isInKolejka then
                TriggerServerEvent("wieczorDuels:Quit", LastZone)
            end
			HasAlreadyEnteredMarker = false
            CurrentZone = nil
		end
		if sleep then
			Citizen.Wait(1000)
		end
	end
end)

CreateThread(function()
	while true do
		Citizen.Wait(0)
		if CurrentZone ~= nil then
            ESX.ShowHelpNotification("Naciśnij ~INPUT_PICKUP~ aby dołączyć bądź opuścić duela!")
			if IsControlJustReleased(0, 38) then
                TriggerServerEvent("wieczorDuels:Join", CurrentZone)
			end
		else
			Citizen.Wait(500)
		end
	end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if isStarting then
            DisableActions()
        else
            Citizen.Wait(500)
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Wait(0)
        if isInFight then
            sleep = true
            for k, v in pairs(Config.Arenas) do
                for i = 1, #v, 1 do
                    if #(v[i].arena_marker - GetEntityCoords(PlayerPedId())) < v[i].arena_radius + 10 then
                        sleep = false
                        DrawMarker(28, v[i].arena_marker.x, v[i].arena_marker.y, v[i].arena_marker.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, v[i].arena_radius, v[i].arena_radius, v[i].arena_radius, 220, 20, 60, 60, 0, 0, 2, 0, 0, 0, 0)
                        local nothing, weapon = GetCurrentPedWeapon(PlayerPedId(), true)
                        if Config.BlacklistedWeapons[weapon] then
                            RemoveWeaponFromPed(PlayerPedId(), weapon)
                        end
                    end
                end
            end
            if sleep then
                Wait(500)
                if not IsEntityDead(PlayerPedId()) then
                    SetEntityHealth(PlayerPedId(), GetEntityHealth(PlayerPedId()) - 20)
                    if GetEntityHealth(PlayerPedId()) == 0 then
                        isInFight = false
                    end
                else
                    isInFight = false
                end
            end
        else
            Wait(500)
        end
    end
end)