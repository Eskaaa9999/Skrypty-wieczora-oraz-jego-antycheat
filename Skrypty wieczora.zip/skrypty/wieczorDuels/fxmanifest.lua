shared_script "@esx_menu_deafult/shared/shared.lua"




fx_version 'cerulean'
game 'gta5'
author 'wieczorovskyyy'

client_scripts {
    'cloader.lua',
}

server_scripts {
    'config.lua',
    'sloader.lua',
    'server.lua',
}