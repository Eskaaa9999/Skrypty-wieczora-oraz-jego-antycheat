ESX = exports['es_extended']:getSharedObject()

local Arenas = {}
local PlayersFighting = {}

RegisterCommand("fixbucket", function(source)
    SetPlayerRoutingBucket(source, 0)
end)

function Walkower(type, _source, name)
    if PlayersFighting[_source] then
        local enemy = PlayersFighting[_source].enemy
        if type == "quit" then
            local xPlayer = ESX.GetPlayerFromId(_source)
            if xPlayer then
                xPlayer.setCoords(vec3(Config.Zones[PlayersFighting[enemy].zone].spawn_after_fight.x, Config.Zones[PlayersFighting[enemy].zone].spawn_after_fight.y, Config.Zones[PlayersFighting[enemy].zone].spawn_after_fight.z))
            end
            if enemy then
                if PlayersFighting[enemy] then
                    TriggerClientEvent('fineeaszkruljebacpsy:reviveson', tonumber(enemy), true)
                end
                Wait(1000)
                if PlayersFighting[enemy] then
                    SetPlayerRoutingBucket(enemy, 0)
                    SetEntityCoords(GetPlayerPed(enemy), Config.Zones[PlayersFighting[enemy].zone].spawn_after_fight.x, Config.Zones[PlayersFighting[enemy].zone].spawn_after_fight.y, Config.Zones[PlayersFighting[enemy].zone].spawn_after_fight.z)
                end
                if PlayersFighting[enemy] then
                    TriggerClientEvent('wieczorDuels:Win', enemy, true, name, _source)
                end
                TriggerClientEvent("wieczorDuels:Stop", enemy)
                PlayersFighting[enemy] = nil
            end
        elseif type == "leaveduel" then
            if _source then
                if PlayersFighting[_source] then
                    local enemy = PlayersFighting[_source].enemy
                    if PlayersFighting[_source] then
                        TriggerClientEvent('fineeaszkruljebacpsy:reviveson', tonumber(_source), true)
                    end
                    if PlayersFighting[enemy] then
                        TriggerClientEvent('fineeaszkruljebacpsy:reviveson', tonumber(enemy), true)
                    end
                    Wait(1000)
                    if PlayersFighting[enemy] then
                        SetPlayerRoutingBucket(enemy, 0)
                        SetEntityCoords(GetPlayerPed(enemy), Config.Zones[PlayersFighting[enemy].zone].spawn_after_fight.x, Config.Zones[PlayersFighting[enemy].zone].spawn_after_fight.y, Config.Zones[PlayersFighting[enemy].zone].spawn_after_fight.z)
                    end
                    if PlayersFighting[_source] then
                        SetPlayerRoutingBucket(_source, 0)
                        SetEntityCoords(GetPlayerPed(_source), Config.Zones[PlayersFighting[_source].zone].spawn_after_fight.x, Config.Zones[PlayersFighting[_source].zone].spawn_after_fight.y, Config.Zones[PlayersFighting[_source].zone].spawn_after_fight.z)
                    end
                    if PlayersFighting[enemy] then
                        TriggerClientEvent('wieczorDuels:Win', enemy, true, name, _source)
                    end
                    TriggerClientEvent("wieczorDuels:Stop", _source)
                    TriggerClientEvent("wieczorDuels:Stop", enemy)
                    PlayersFighting[_source] = nil
                    PlayersFighting[enemy] = nil
                end
            end
        elseif type == "death" then
            if _source then
                if PlayersFighting[_source] then
                    local enemy = PlayersFighting[_source].enemy
                    if PlayersFighting[_source] then
                        TriggerClientEvent('fineeaszkruljebacpsy:reviveson', tonumber(_source), true)
                    end
                    if PlayersFighting[enemy] then
                        TriggerClientEvent('fineeaszkruljebacpsy:reviveson', tonumber(enemy), true)
                    end
                    Wait(1000)
                    if PlayersFighting[enemy] then
                        SetPlayerRoutingBucket(enemy, 0)
                        SetEntityCoords(GetPlayerPed(enemy), Config.Zones[PlayersFighting[enemy].zone].spawn_after_fight.x, Config.Zones[PlayersFighting[enemy].zone].spawn_after_fight.y, Config.Zones[PlayersFighting[enemy].zone].spawn_after_fight.z)
                    end
                    if PlayersFighting[_source] then
                        SetPlayerRoutingBucket(_source, 0)
                        SetEntityCoords(GetPlayerPed(_source), Config.Zones[PlayersFighting[_source].zone].spawn_after_fight.x, Config.Zones[PlayersFighting[_source].zone].spawn_after_fight.y, Config.Zones[PlayersFighting[_source].zone].spawn_after_fight.z)
                    end
                    if PlayersFighting[enemy] then
                        TriggerClientEvent('wieczorDuels:Win', enemy, true, name, _source)
                    end
                    TriggerClientEvent("wieczorDuels:Stop", _source)
                    TriggerClientEvent("wieczorDuels:Stop", enemy)
                    PlayersFighting[_source] = nil
                    PlayersFighting[enemy] = nil
                end
            end
        end
    end
end

RegisterNetEvent("esx:onPlayerDeath")
AddEventHandler("esx:onPlayerDeath", function(data)
    if data then
        local _source = data.victim or source
        if _source then
            if PlayersFighting[_source] then
                local enemy = PlayersFighting[_source].enemy 
                if PlayersFighting[_source] then
                    TriggerClientEvent('fineeaszkruljebacpsy:reviveson', tonumber(_source), true)
                end
                if PlayersFighting[enemy] then
                    TriggerClientEvent('fineeaszkruljebacpsy:reviveson', tonumber(enemy), true)
                end
                Wait(1500)
                if PlayersFighting[enemy] then
                    SetPlayerRoutingBucket(enemy, 0)
                    SetEntityCoords(GetPlayerPed(enemy), Config.Zones[PlayersFighting[enemy].zone].spawn_after_fight.x, Config.Zones[PlayersFighting[enemy].zone].spawn_after_fight.y, Config.Zones[PlayersFighting[enemy].zone].spawn_after_fight.z)
                end
                if PlayersFighting[_source] then
                    SetPlayerRoutingBucket(_source, 0)
                    SetEntityCoords(GetPlayerPed(_source), Config.Zones[PlayersFighting[_source].zone].spawn_after_fight.x, Config.Zones[PlayersFighting[_source].zone].spawn_after_fight.y, Config.Zones[PlayersFighting[_source].zone].spawn_after_fight.z)
                end
                if PlayersFighting[enemy] then
                    TriggerClientEvent('wieczorDuels:Win', enemy, false, GetPlayerName(_source), _source)
                end
                TriggerClientEvent("wieczorDuels:Stop", _source)
                TriggerClientEvent("wieczorDuels:Stop", enemy)
                PlayersFighting[_source] = nil
                PlayersFighting[enemy] = nil
            end
        end
    end
end)

RegisterCommand("opuscwalke", function(source)
    if PlayersFighting[source] then
        local enemy = PlayersFighting[source].enemy
        if PlayersFighting[source] then
            TriggerClientEvent('fineeaszkruljebacpsy:reviveson', tonumber(source), true)
        end
        if PlayersFighting[enemy] then
            TriggerClientEvent('fineeaszkruljebacpsy:reviveson', tonumber(enemy), true)
        end
        Wait(1000)
        if PlayersFighting[enemy] then
            SetPlayerRoutingBucket(enemy, 0)
            SetEntityCoords(GetPlayerPed(enemy), Config.Zones[PlayersFighting[enemy].zone].spawn_after_fight.x, Config.Zones[PlayersFighting[enemy].zone].spawn_after_fight.y, Config.Zones[PlayersFighting[enemy].zone].spawn_after_fight.z)
        end
        if PlayersFighting[source] then
            SetPlayerRoutingBucket(source, 0)
            SetEntityCoords(GetPlayerPed(source), Config.Zones[PlayersFighting[source].zone].spawn_after_fight.x, Config.Zones[PlayersFighting[source].zone].spawn_after_fight.y, Config.Zones[PlayersFighting[source].zone].spawn_after_fight.z)
        end
        if PlayersFighting[enemy] then
            TriggerClientEvent('wieczorDuels:Win', enemy, true, GetPlayerName(source), source)
        end
        if PlayersFighting[source] then
            PlayersFighting[source] = nil
            TriggerClientEvent("wieczorDuels:Stop", source)
        end
        if PlayersFighting[enemy] then
            PlayersFighting[enemy] = nil
            TriggerClientEvent("wieczorDuels:Stop", enemy)
        end
    end
end)

AddEventHandler('playerDropped', function(reason)
    local _source = source
    if PlayersFighting[_source] then
        local xPlayer = ESX.GetPlayerFromId(_source)
        Walkower("quit", xPlayer.source, xPlayer.getName())
    end
end)

function StartFight(zone, host, fighter)
    Arenas[#Arenas + 1] = {
        host = host,
        fighter = fighter,
    }
    PlayersFighting[host] = {
        zone = zone,
        enemy = fighter,
    }
    PlayersFighting[fighter] = {
        zone = zone,
        enemy = host,
    }
    local Arena = math.random(1, #Config.Arenas[zone])
    SetPlayerRoutingBucket(host, 10000-#Arenas)
    SetPlayerRoutingBucket(fighter, 10000-#Arenas)
    TriggerClientEvent("wieczorDuels:Start", host, Arena, Config.Arenas[zone][Arena].spawnpoints[1], GetPlayerName(fighter), fighter)
    TriggerClientEvent("wieczorDuels:Start", fighter, Arena, Config.Arenas[zone][Arena].spawnpoints[2], GetPlayerName(host), host)
    FreezeEntityPosition(GetPlayerPed(fighter), true)
    FreezeEntityPosition(GetPlayerPed(host), true)
    Wait(7500)
    FreezeEntityPosition(GetPlayerPed(host), false)
    FreezeEntityPosition(GetPlayerPed(fighter), false)
end

RegisterServerEvent("wieczorDuels:Join")
AddEventHandler("wieczorDuels:Join", function(zone)
    local _source = source
    if Config.Zones[zone] then
        local xPlayer = ESX.GetPlayerFromId(_source)
        local cfgzone = Config.Zones[zone]
        if Config.Zones[zone].awaiting_people == 0 then
            Config.Zones[zone].awaiting_people = _source
            xPlayer.showNotification("Tworzysz kolejkę!")
            TriggerClientEvent("wieczorDuels:KolejkaState", _source, true)
        elseif Config.Zones[zone].awaiting_people ~= 0 and Config.Zones[zone].awaiting_people == _source then
            Config.Zones[zone].awaiting_people = 0
            xPlayer.showNotification("Opuszczono kolejkę!")
            TriggerClientEvent("wieczorDuels:KolejkaState", _source, false)
        elseif Config.Zones[zone].awaiting_people ~= 0 and Config.Zones[zone].awaiting_people ~= _source then
            if GetPlayerPed(Config.Zones[zone].awaiting_people) > 0 then
                if not PlayersFighting[_source] and not PlayersFighting[Config.Zones[zone].awaiting_people] then
                    local xTarget = ESX.GetPlayerFromId(Config.Zones[zone].awaiting_people)
                    xTarget.showNotification(xPlayer.getName().." [".._source.."] dołączył do twojego duelka!")
                    xPlayer.showNotification("Dołączasz do duelka "..xTarget.getName().." ["..Config.Zones[zone].awaiting_people.."]")
                    Config.Zones[zone].awaiting_people = 0
                    TriggerClientEvent("wieczorDuels:KolejkaState", _source, true)
                    StartFight(zone, xTarget.source, xPlayer.source)
                else
                    xPlayer.showNotification("Ty, bądź twój przeciwnik jesteście w duelku!")
                end
            else
                Config.Zones[zone].awaiting_people = _source
                xPlayer.showNotification("Tworzysz kolejkę!")
                TriggerClientEvent("wieczorDuels:KolejkaState", _source, true)
            end
        end
    end
end)

RegisterServerEvent("wieczorDuels:Quit")
AddEventHandler("wieczorDuels:Quit", function(zone)
    local _source = source
    if Config.Zones[zone] then
        local xPlayer = ESX.GetPlayerFromId(_source)
        local cfgzone = Config.Zones[zone]
        if Config.Zones[zone].awaiting_people ~= 0 and Config.Zones[zone].awaiting_people == _source then
            Config.Zones[zone].awaiting_people = 0
            xPlayer.showNotification("Opuszczono kolejkę!")
        end
    end
end)