ESX = nil
PlayerData = {}
PlayerLoaded = false
isDead = false

Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent("Niggerzafryki:autokillprocces", function(o) ESX = o end)
		Citizen.Wait(0)
	end
	PlayerData = ESX.GetPlayerData()
    PlayerLoaded = true
end)

RegisterNetEvent("esx:playerLoaded")
AddEventHandler("esx:playerLoaded", function(xPlayer)
	PlayerData = xPlayer
	PlayerLoaded = true
end)

RegisterNetEvent("esx:setJob")
AddEventHandler("esx:setJob", function(data)
	PlayerData.job = data
end)

AddEventHandler("esx:onPlayerDeath", function(data)
	isDead = true
end)

AddEventHandler("esx:onPlayerSpawn", function(spawn)
	isDead = false
end)

hasAlreadyEnteredMarker = false
LastStation, LastPart, LastPartNum, LastEntity, CurrentAction, CurrentActionPart, CurrentActionScript = nil
CurrentActionMsg = ""
Markers = {}

exports("remove", function(name)
	Markers[name] = nil
end)

exports("new", function(name, coords, options, res, action)
	local job = nil
	local grade = 0
	local radius = 1.5
	local message = ""
	local type = 25
	local flip = 0.0
	local color = {r = 28, g = 27, b = 30, a = 100} -- 28, 27, 30
	local color2 = {r = 23, g = 189, b = 122, a = 150}
	local floatingText = nil
	local floatingTextDistance = 5.0
	local floatingTextHideInside = false
	local draw = true
	local data = nil
	local faceCamera = false
	local inVehicle = false
	if options.radius then
		radius = options.radius
	end
	local scaleX = radius
	local scaleY = radius
	local scaleZ = radius
	if options.job then
		job = options.job
	end
	if options.grade then
		grade = options.grade
	end
	if options.message then
		message = options.message
	end
	if options.color then
		color = options.color
	end
	if options.color2 then
		color2 = options.color2
	elseif options.color then
		color2 = options.color
	end
	if options.type then
		type = options.type
	end
	if options.flip then
		flip = options.flip
	end
	if options.floatingText then
		floatingText = options.floatingText
	end
	if options.floatingTextDistance then
		floatingTextDistance = options.floatingTextDistance
	end
	if options.floatingTextHideInside then
		floatingTextHideInside = options.floatingTextHideInside
	end
	if options.draw == false then
		draw = options.draw
	end
	if options.data then
		data = options.data
	end
	if options.scaleX then
		scaleX = options.scaleX
	end
	if options.scaleY then
		scaleY = options.scaleY
	end
	if options.scaleZ then
		scaleZ = options.scaleZ
	end
	if options.faceCamera then
		faceCamera = options.faceCamera
	end
	if options.inVehicle ~= nil then
		inVehicle = options.inVehicle
	end
	Markers[name] = {
		CurrentAction = action,
		CurrentActionMsg = message,
		Coordinates = coords,
		Resource = res,
		data = data,
		job = job,
		grade = grade,
		radius = radius,
		type = type,
		flip = flip,
		floatingText = floatingText,
		floatingTextDistance = floatingTextDistance,
		floatingTextHideInside = floatingTextHideInside,
		draw = draw,
		color = color,
		color2 = color2,
		scaleX = scaleX,
		scaleY = scaleY,
		scaleZ = scaleZ,
		faceCamera = faceCamera,
		inVehicle = inVehicle,
	}
end)

AddEventHandler("wieczorMarkersAndBlips:hasEnteredMarker", function(part)
	CurrentAction = Markers[part].CurrentAction
	CurrentActionScript = Markers[part].Resource
	CurrentActionData = Markers[part].data
	CurrentActionPart = part
end)

AddEventHandler("wieczorMarkersAndBlips:hasExitedMarker", function(part)
	CurrentAction, CurrentActionMsg, CurrentActionScript, CurrentActionPart = nil
	ESX.UI.Menu.CloseAll()
end)

RegisterCommand("+wieczorMarkersContextAction", function()
end)

RegisterCommand("-wieczorMarkersContextAction", function()
	if CurrentAction ~= nil and Markers[CurrentActionPart].CurrentAction ~= nil then
		CurrentAction({
			CurrentAction = CurrentAction,
			CurrentActionMsg = CurrentActionMsg,
			CurrentActionScript = CurrentActionScript,
			CurrentActionData = CurrentActionData,
			CurrentActionPart = CurrentActionPart
		})
	end
end)

RegisterKeyMapping("+wieczorMarkersContextAction", "Interakcja kontekstowa", "keyboard", "E")

TriggerEvent("chat:removeSuggestion", "/+wieczorMarkersContextAction")
TriggerEvent("chat:removeSuggestion", "/-wieczorMarkersContextAction")

Citizen.CreateThread(function()
	Citizen.Wait(5000)
	while true do
		local playerPed = PlayerPedId()
		local coords = GetEntityCoords(playerPed)
		local isInMarker, hasExited, letSleep = false, false, true
		local currentStation, currentPart, currentPartNum, currentScript, currentScriptAction
		for Key, Value in pairs(Markers) do
			if Value.inVehicle then
				if IsPedInAnyVehicle(PlayerPedId(), false) then
					local distance = #(coords - Value.Coordinates)
					if distance < Value.radius then
						if Value.draw then
							exports['xenon_helpnotify']:ShowHelpNotification(Value.CurrentActionMsg)
							DrawMarker(Value.type, Value.Coordinates.x, Value.Coordinates.y, Value.Coordinates.z - 1, 0.0, 0.0, 0.0, 0.0 - Value.flip, 0.0, 0.0, Value.scaleX, Value.scaleY, Value.scaleZ, Value.color2.r, Value.color2.g, Value.color2.b, Value.color2.a, false, Value.faceCamera, 2, false, false, false, false)
						end
						isInMarker, currentStation, currentPart, currentPartNum = true, Key, Key, Iterator
						letSleep = false
						if Value.floatingText and not Value.floatingTextHideInside then
							drawFloatingHelp(Value.floatingText, Value.Coordinates)
						end
					elseif distance > Value.radius and distance < 20.0 then
						if Value.draw then
							DrawMarker(Value.type, Value.Coordinates.x, Value.Coordinates.y, Value.Coordinates.z - 1, 0.0, 0.0, 0.0, 0.0 - Value.flip, 0.0, 0.0, Value.scaleX, Value.scaleY, Value.scaleZ, Value.color.r, Value.color.g, Value.color.b, Value.color.a, false, Value.faceCamera, 2, false, false, false, false)
						end
						letSleep = false
						if Value.floatingText and distance < Value.floatingTextDistance then
							drawFloatingHelp(Value.floatingText, Value.Coordinates)
						end
					end
				end
			end
			if Value.job then
				if (not Value.job or (PlayerData.job.name == Value.job and PlayerData.job.grade >= Value.grade)) then
					local distance = #(coords - Value.Coordinates)
					if distance < Value.radius then
						if Value.draw then
							exports['xenon_helpnotify']:ShowHelpNotification(Value.CurrentActionMsg)
							DrawMarker(Value.type, Value.Coordinates.x, Value.Coordinates.y, Value.Coordinates.z - 1, 0.0, 0.0, 0.0, 0.0 - Value.flip, 0.0, 0.0, Value.scaleX, Value.scaleY, Value.scaleZ, Value.color2.r, Value.color2.g, Value.color2.b, Value.color2.a, false, Value.faceCamera, 2, false, false, false, false)
						end
						isInMarker, currentStation, currentPart, currentPartNum = true, Key, Key, Iterator
						letSleep = false
                        if Value.floatingText and not Value.floatingTextHideInside then
                            drawFloatingHelp(Value.floatingText, Value.Coordinates)
                        end
					elseif distance > Value.radius and distance < 20.0 then
						if Value.draw then
							DrawMarker(Value.type, Value.Coordinates.x, Value.Coordinates.y, Value.Coordinates.z - 1, 0.0, 0.0, 0.0, 0.0 - Value.flip, 0.0, 0.0, Value.scaleX, Value.scaleY, Value.scaleZ, Value.color.r, Value.color.g, Value.color.b, Value.color.a, false, Value.faceCamera, 2, false, false, false, false)
						end
						letSleep = false
						if Value.floatingText and distance < Value.floatingTextDistance then
							drawFloatingHelp(Value.floatingText, Value.Coordinates)
						end
					end
				end
			elseif (not Value.job and not Value.inVehicle or ((PlayerData.job[Value.job] and PlayerData.job[Value.job].name == Value.job) and (PlayerData.job[Value.job] and PlayerData.job[Value.job].grade >= Value.grade))) then
				local distance = #(coords - Value.Coordinates) -- Calculate distance between coordinates using language-native function
				if distance < Value.radius then
					if Value.draw then
						exports['xenon_helpnotify']:ShowHelpNotification(Value.CurrentActionMsg)
						DrawMarker(Value.type, Value.Coordinates.x, Value.Coordinates.y, Value.Coordinates.z - 1, 0.0, 0.0, 0.0, 0.0 - Value.flip, 0.0, 0.0, Value.scaleX, Value.scaleY, Value.scaleZ, Value.color2.r, Value.color2.g, Value.color2.b, Value.color2.a, false, Value.faceCamera, 2, false, false, false, false)
					end
					isInMarker, currentStation, currentPart, currentPartNum = true, Key, Key, Iterator
					letSleep = false
					if Value.floatingText and not Value.floatingTextHideInside then
						drawFloatingHelp(Value.floatingText, Value.Coordinates)
					end
				elseif distance > Value.radius and distance < 20.0 then
					if Value.draw then
						DrawMarker(Value.type, Value.Coordinates.x, Value.Coordinates.y, Value.Coordinates.z - 1, 0.0, 0.0, 0.0, 0.0 - Value.flip, 0.0, 0.0, Value.scaleX, Value.scaleY, Value.scaleZ, Value.color.r, Value.color.g, Value.color.b, Value.color.a, false, Value.faceCamera, 2, false, false, false, false)
					end
					letSleep = false
					if Value.floatingText and distance < Value.floatingTextDistance then
						drawFloatingHelp(Value.floatingText, Value.Coordinates)
					end
				end
			end
		end
		if isInMarker and not HasAlreadyEnteredMarker or (isInMarker and (LastStation ~= currentStation or LastPart ~= currentPart or LastPartNum ~= currentPartNum)) then
			if (LastStation and LastPart and LastPartNum) and (LastStation ~= currentStation or LastPart ~= currentPart or LastPartNum ~= currentPartNum) then
				TriggerEvent("wieczorMarkersAndBlips:hasExitedMarker", LastStation, LastPart, LastPartNum)
				hasExited = true
			end
			HasAlreadyEnteredMarker = true
			LastStation = currentStation
			LastPart = currentPart
			LastPartNum = currentPartNum
			TriggerEvent("wieczorMarkersAndBlips:hasEnteredMarker", currentPart)
		end
		if not hasExited and not isInMarker and HasAlreadyEnteredMarker then
			HasAlreadyEnteredMarker = false
			TriggerEvent("wieczorMarkersAndBlips:hasExitedMarker", LastStation, LastPart, LastPartNum)
		end
		if letSleep then
			Citizen.Wait(500)
		else
			Citizen.Wait(0)
		end
	end
end)

