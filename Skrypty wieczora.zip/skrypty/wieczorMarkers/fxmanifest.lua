shared_script "@esx_menu_deafult/shared/shared.lua"



fx_version 'bodacious'
game 'gta5'

client_script {
	'client.lua',
}

