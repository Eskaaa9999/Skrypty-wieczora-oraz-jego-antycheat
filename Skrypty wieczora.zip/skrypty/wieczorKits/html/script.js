window.addEventListener('message', (event) => {
    let data = event.data
    if (data.action == "openMenu") {
        $("#kits").show();
    }
});

function closeMenu() {
    $("#kits").hide();
    $.post("http://wieczorKits/closeMenu", JSON.stringify({}))
}

function gracz() {
    closeMenu()
    $.post("http://wieczorKits/getKit", JSON.stringify({ type: "gracz" }))
}

function friend() {
    closeMenu()
    $.post("http://wieczorKits/getKit", JSON.stringify({ type: "friend" }))
}

function bogacz() {
    closeMenu()
    $.post("http://wieczorKits/getKit", JSON.stringify({ type: "bogacz" }))
}
