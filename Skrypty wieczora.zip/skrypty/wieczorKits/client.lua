ESX = exports['es_extended']:getSharedObject()

RegisterCommand("kit", function()
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = "openMenu",
        dailycase = 0,
    })
end)

RegisterNUICallback("closeMenu", function()
    SetNuiFocus(false, false)
end)

RegisterNUICallback("getKit", function(xd, xd2)
    TriggerServerEvent("wieczorKits:getKit", xd.type)
end)