ESX = exports['es_extended']:getSharedObject()

RegisterServerEvent("wieczorKits:getKit")
AddEventHandler("wieczorKits:getKit", function(type)
    local xPlayer = ESX.GetPlayerFromId(source)
    local identifier = xPlayer.identifier
    local digit = xPlayer.getDigit()
    MySQL.single("SELECT kit_gracz, kit_friend, kit_bogacz FROM users WHERE identifier = ? AND digit = ?", { identifier, digit }, function(result)
        if result then  
            if type == "bogacz" then
                if result.kit_bogacz == 0 then
                    MySQL.update("UPDATE users SET kit_bogacz = ? WHERE identifier = ? AND digit = ?", {1, identifier, digit}, function(result)
                        xPlayer.addInventoryItem("weaponchest4", 20)
                        xPlayer.addInventoryItem("skrzyniaogg4", 10)
                        xPlayer.addInventoryItem("premiumchest4", 15)
                        xPlayer.addInventoryItem("carchest4", 5)
                        xPlayer.showNotification("Odebrano kit bogacz, gratulacje!")
                    end)
                else
                    xPlayer.showNotification("Kit możesz zakupić na naszej stronie: indrop.gg/s/xenonrp!")
                end
            elseif type == "friend" then
                if result.kit_friend == 0 then
                    MySQL.update("UPDATE users SET kit_friend = ? WHERE identifier = ? AND digit = ?", {1, identifier, digit}, function(result)
                        xPlayer.addInventoryItem("weaponchest4", 15)
                        xPlayer.addInventoryItem("skrzyniaogg4", 5)
                        xPlayer.addMoney(15000000)
                        xPlayer.showNotification("Odebrano kit friend, gratulacje!")
                    end)
                else
                    xPlayer.showNotification("Kit możesz zakupić na naszej stronie: indrop.gg/s/xenonrp!")
                end
            elseif type == "gracz" then
                if result.kit_gracz == 0 then
                    MySQL.update("UPDATE users SET kit_gracz = ? WHERE identifier = ? AND digit = ?", {1, identifier, digit}, function(result)
                        xPlayer.addInventoryItem("bread", 45)
                        xPlayer.addInventoryItem("water", 45)
                        xPlayer.addInventoryItem("kawa", 30)
                        xPlayer.addInventoryItem("radio", 3)
                        xPlayer.addInventoryItem("weaponchest4", 2)
                        xPlayer.addInventoryItem("carchest4", 1)
                        xPlayer.showNotification("Odebrano kit gracz, gratulacje!")
                    end)
                else
                    xPlayer.showNotification("Odebrałeś już ten kit!")
                end
            end
        end
    end)
end)

RegisterCommand("dajkitfriend", function(source, args, raw)
    if source == 0 then
        if args[1] then
            local xPlayer = ESX.GetPlayerFromId(args[1])
            MySQL.update("UPDATE users SET kit_friend = ? WHERE identifier = ? AND digit = ?", {0, xPlayer.identifier, xPlayer.getDigit() }, function(result)
                xPlayer.showNotification("Otrzymano kit friend!")
            end)
        end
    end
end)

RegisterCommand("dajkitbogacz", function(source, args, raw)
    if source == 0 then
        if args[1] then
            local xPlayer = ESX.GetPlayerFromId(args[1])
            MySQL.update("UPDATE users SET kit_bogacz = ? WHERE identifier = ? AND digit = ?", {0, xPlayer.identifier, xPlayer.getDigit() }, function(result)
                xPlayer.showNotification("Otrzymano kit bogacz!")
            end)
        end
    end
end)