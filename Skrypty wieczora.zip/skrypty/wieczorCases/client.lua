ESX = exports['es_extended']:getSharedObject()

RegisterNUICallback('CloseCase', function(data, cb)
	SetNuiFocus(false,false)
	TriggerServerEvent('wczrCases:giveReward')
end)


RegisterNetEvent("wczrCases:openvanecases")
AddEventHandler("wczrCases:openvanecases", function(chest, win)
    SetNuiFocus(true,true)
    SendNUIMessage({
        action = "OpenCase",
        label = Config.Cases[chest].label,
        chest = chest,
		items = win.data,
		win = win.win,
    })
end)