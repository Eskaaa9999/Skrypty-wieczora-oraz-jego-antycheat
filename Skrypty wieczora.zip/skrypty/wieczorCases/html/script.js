

let wintier = "";

window.addEventListener('message', (event) => {
    let data = event.data
    if (data.action == "OpenCase") {
        $('#case').show();
        $('#button').show();
        $('#items').show();
        $("#chest").show();
        $("#winning").hide();
        $('#label').html(data.label);
        switch(data.win.type) {
            case "item":
                wintier = data.win.tier
                if (data.win.img) {
                    $("#winning").html(`
                        <div id="item" class="${data.win.tier} ${data.win.tier}-bg">
                            <img src="img/${data.win.img}.png">
                            <div class="text">${data.win.label}</div>
                            <div class="text2">${data.win.amount}x</div>
                        </div>
                    `)
                } else {
                    $("#winning").html(`
                        <div id="item" class="${data.win.tier} ${data.win.tier}-bg">
                            <img src="img/${data.win.item}.png">
                            <div class="text">${data.win.label}</div>
                            <div class="text2">${data.win.amount}x</div>
                        </div>
                    `)
                }
                break;
            case "money":
                wintier = data.win.tier
                $("#winning").html(`
                    <div id="item" class="${data.win.tier} ${data.win.tier}-bg">
                        <img src="img/money.png">
                        <div class="text">${data.win.label}</div>
                        <div class="text2">${data.win.amount}x</div>
                    </div>
                `)
                break;
            case "weapon":
                wintier = data.win.tier
                $("#winning").html(`
                    <div id="item" class="${data.win.tier} ${data.win.tier}-bg">
                        <img src="img/${data.win.item}.png">
                        <div class="text">${data.win.label}</div>
                        <div class="text2">${data.win.amount}x</div>
                    </div>
                `)
                break;
            case "vehicle":
                wintier = data.win.tier
                $("#winning").html(`
                    <div id="item" class="${data.win.tier} ${data.win.tier}-bg">
                        <img src="img/vehicle.png">
                        <div class="text">${data.win.label}</div>
                        <div class="text2">${data.win.amount}x</div>
                    </div>
                `)
                break;
        }
        $('#chest').html('<img src="img/' + data.chest + '.png">')
        for (i = 0; i < data.items.length; i++) {
            if (data.items[i].img) {
                $('#items').append(`
                <div id="item" class="${data.items[i].tier}">
                    <img src="img/${data.items[i].img}.png">
                    <div class="text">${data.items[i].label}</div>
                    <div class="text2">${data.items[i].amount}x</div>
                </div>
            `);     
            } else {
                $('#items').append(`
                    <div id="item" class="${data.items[i].tier}">
                        <img src="img/${data.items[i].item}.png">
                        <div class="text">${data.items[i].label}</div>
                        <div class="text2">${data.items[i].amount}x</div>
                    </div>
                `);                
            }
        }
    }
});

function openCase() {
    $('#button').hide();
    $('#items').hide();
    $('#chest').css({
        "top": "30vh",
        "left": "44vw",
    })
    $('#chest img').css({
        "width": "175%",
        "height": "175%",
    })
    setTimeout(function() {
        $('#chest').hide();
        $('#winning').show();
        setTimeout(function() {
            $('#chest').css({
                "top": "11%",
                "left": "50vw",
            })
            $("#case").hide();
            $("#items").empty();
            $("#chest").empty();
            $("#winning").empty();
            $.post(`http://wieczorCases/CloseCase`, JSON.stringify({}))
        }, 5000)
    }, 1500)
}