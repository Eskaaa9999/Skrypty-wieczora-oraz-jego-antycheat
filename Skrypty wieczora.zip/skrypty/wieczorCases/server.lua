ESX = exports['es_extended']:getSharedObject()
local playerWinnings = {}

CreateThread(function()
	for k, v in pairs(Config.Cases) do
		ESX.RegisterUsableItem(k, function(source)
			local xPlayer = ESX.GetPlayerFromId(source)
			if not playerWinnings[source] then
				xPlayer.removeInventoryItem(k, 1)
				local winning = calculateWin(k)
				playerWinnings[source] = winning
				TriggerClientEvent('wczrCases:openvanecases', source, k, winning)
			end
		end)
	end
end)

AddEventHandler("playerDropped", function() 
	playerWinnings[source] = nil
end)

function calculateWin(type) 
	local sum = 0
	draw = {}
	for k, v in ipairs(Config.Cases[type].list) do
		local rate = Config.Chances[v.tier].rate * 100
		for i = 1, rate do 
			if v.type == "item" then
				if v.amount then
					table.insert(draw, {type = "item", item = v.item, amount = v.amount, tier = v.tier, label = v.label, img = v.img})
				else
					table.insert(draw, {type = "item", item = v.item, amount = 1, tier = v.tier, label = v.label, img = v.img})
				end
			elseif v.type == "weapon" then
				table.insert(draw, {type = "weapon", item = v.item, weapon = v.weapon, amount = v.amount, tier = v.tier, label = v.label})
			elseif v.type == "vehicle" then
				table.insert(draw, {type = "vehicle", item = "vehicle", vehicle = v.vehicle, tier = v.tier, label = v.label, amount = v.amount})
			elseif v.type == "money" then
				table.insert(draw, {type = "money", item = "money", amount = v.amount, tier = v.tier, label = v.label})
			end
			i = i + 1
		end
		sum = sum + rate
	end
	local random = math.random(1,sum)
	local data = Config.Cases[type].list
	local win = draw[random]
	return {data = data, win = win}
end

RegisterServerEvent('wczrCases:giveReward', function() 
	local src = source
	if not playerWinnings[src] then
		exports.esx_menu_deafult:banPlayer(src, "Tried to trigger wczrCases:giveReward in wieczorCases")
		return
	end
	local xPlayer = ESX.GetPlayerFromId(src)
	local win = playerWinnings[src].win
	if win.type == "item" then
		xPlayer.addInventoryItem(win.item, win.amount)
		exports['xenon_logs']:SendLog(src, "Wylosowal "..win.item.." x"..win.amount.."", 'skrzynki', '5793266')
		print("^0[^6XenonRP^0-^4Handler^0] ^0[^5SKRZYNKI^0]: ^3["..src.."] ^0wylosował ^5"..win.item.." x"..win.amount.." ^0ze skrzynki")
	elseif win.type == "weapon" then
		xPlayer.addInventoryWeapon(win.item, win.amount, 100, false)
		exports['xenon_logs']:SendLog(src, "Wylosowal "..win.item.." x"..win.amount.." z 100 ammo", 'skrzynki', '5793266')
		print("^0[^6XenonRP^0-^4Handler^0] ^0[^5SKRZYNKI^0]: ^3["..src.."] ^0wylosował ^5"..win.item.." x"..win.amount.." (100 ammo) ^0ze skrzynki")
	elseif win.type == "money" then
		xPlayer.addMoney(win.amount)
		exports['xenon_logs']:SendLog(src, "Wylosowal "..win.amount.."$", 'skrzynki', '5793266')
		print("^0[^6XenonRP^0-^4Handler^0] ^0[^5SKRZYNKI^0]: ^3["..src.."] ^0wylosował ^5"..win.amount.."$ ^0ze skrzynki")
	elseif win.type == "vehicle" then
		TriggerClientEvent("fineeasztobocianilatawogolgodmuhahaha", src, win.vehicle)
		print("^0[^6XenonRP^0-^4Handler^0] ^0[^5SKRZYNKI^0]: ^3["..src.."] ^0wylosował ^5"..win.vehicle.." ^0ze skrzynki")
	end
	TriggerClientEvent("csskrouble:save", src)
	playerWinnings[src] = nil
end)