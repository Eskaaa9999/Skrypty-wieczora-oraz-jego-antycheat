let progressbar1, progressbar2, progressbar3, progressbar4

function showProgressBar(title, time) {
    $('#progressbar-val').css('transition', `width linear 0s`);
    $('#progressbar-val').css('width', '0');
    $('#progressbar-title').html(title);
    $('#progressbar').css('height', '4.5vh');
    progressbar1 = setTimeout(function (){
        $('#progressbar').css('opacity', '1');
    }, 500);
    progressbar2 = setTimeout(function (){
        $('#progressbar-val').css('transition', `width linear ${time / 1000 + "s"}`);
        $('#progressbar-val').css('width', '100%');
    }, 1000);
    progressbar3 = setTimeout(function (){
        $('#progressbar').css('opacity', '0');
        sendRequest("finishProgressBar")
    }, 1000 + time);
    progressbar4 = setTimeout(function (){
        $('#progressbar').css('height', '0');
    }, 1000 + time + 500);
}

function cancelProgressBar() {
    $('#progressbar').css('opacity', '0');
    $('#progressbar').css('height', '0');
    clearTimeout(progressbar1);
    clearTimeout(progressbar2);
    clearTimeout(progressbar3);
    clearTimeout(progressbar4);
}

window.addEventListener('message', (event) => {
    let data = event.data
    switch(data.action) {
        case "showProgressBar":
            showProgressBar(data.label, data.duration)
            break
        case "cancelProgressBar":
            cancelProgressBar();
            break
            default: break;
    }
});

function sendRequest(action, data){
    $.post(`http://${GetParentResourceName()}/sendRequest`, JSON.stringify({action: action, data: data}));
}
