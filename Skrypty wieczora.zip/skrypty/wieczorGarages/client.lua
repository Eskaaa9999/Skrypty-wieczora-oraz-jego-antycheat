ESX = exports['es_extended']:getSharedObject()

local HasAlreadyEnteredMarker = false
local CurrentZone = nil
local LastZone = nil

local MyVehicles = {}

function Draw3DText(coords,textInput,fontId,scaleX,scaleY)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    local dist = GetDistanceBetweenCoords(px,py,pz, coords.x,coords.y,coords.z, 1)    
    local scale = (1/dist)*20
    local fov = (1/GetGameplayCamFov())*100
    local scale = scale*fov   
    SetTextScale(scaleX*scale, scaleY*scale)
    SetTextFont(fontId)
    SetTextProportional(1)
    SetTextColour(200, 200, 200, 255)
    SetTextDropshadow(31, 31, 31, 0.5, 255)
    SetTextEdge(2, 0, 0, 0, 150)
    SetTextDropShadow()
    SetTextOutline()
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(textInput)
    SetDrawOrigin(coords.x,coords.y,coords.z+2, 0)
    DrawText(0.0, 0.0)
    ClearDrawOrigin()
end

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		local coords, sleep = GetEntityCoords(PlayerPedId()), true
		for k,v in pairs(Config.Garages) do
			if (#(coords - v.coords) < 25.0) then
				sleep = false
				ESX.DrawBigMarker(v.coords)
                Draw3DText(v.coords, "~g~GARAŻ" , 4, 0.1, 0.1)
			end
		end
		if (#(coords - Config.GarageOptions) < 25.0) then
			sleep = false
			ESX.DrawMarker(Config.GarageOptions)
			Draw3DText(Config.GarageOptions, "~g~ZARZĄDZANIE POJAZDAMI" , 4, 0.1, 0.1)
		end
		if sleep then
			Citizen.Wait(750)
		end
	end
end)

Citizen.CreateThread(function()
	Citizen.Wait(1000)
	for i=1, #Config.Garages, 1 do
		if Config.Garages[i].blip then
			local blip = AddBlipForCoord(Config.Garages[i].coords)
			SetBlipSprite (blip, 289)
			SetBlipDisplay(blip, 4)
			SetBlipScale(blip, 0.65)
			SetBlipColour (blip, 38)	
			SetBlipAsShortRange(blip, true)
			BeginTextCommandSetBlipName("STRING")
			AddTextComponentString('Garaż publiczny')
			EndTextCommandSetBlipName(blip)
		end
	end	
end)

CreateThread(function()
	while true do
		Citizen.Wait(0)
		local coords, sleep = GetEntityCoords(PlayerPedId()), true
		local isInMarker  = false
        local zone = ""
		for k,v in pairs(Config.Garages) do
			if #(coords - v.coords) < 3.5 then
				sleep = false
				isInMarker = true
                zone = "garage"
			end
		end
		if #(coords - Config.GarageOptions) < 3.5 then
			sleep = false
			isInMarker = true
			zone = "vehicleoptions"
		end
		if isInMarker and not HasAlreadyEnteredMarker then
			HasAlreadyEnteredMarker = true
            CurrentZone = zone
            LastZone = zone
		end
		if not isInMarker and HasAlreadyEnteredMarker then
			HasAlreadyEnteredMarker = false
            CurrentZone = nil
		end
		if sleep then
			Citizen.Wait(1000)
		end
	end
end)

CreateThread(function()
	while true do
		Citizen.Wait(0)
		if CurrentZone ~= nil then
			if CurrentZone == "garage" then
				ESX.ShowHelpNotification("Naciśnij ~INPUT_PICKUP~ otworzyć garaż!")
				if IsControlJustReleased(0, 38) then
					if IsPedInAnyVehicle(PlayerPedId(), true) then
						local veh = GetVehiclePedIsUsing(PlayerPedId())
						local vehProperties = ESX.Game.GetVehicleProperties(veh)
						if GetPedInVehicleSeat(veh, -1) == PlayerPedId() then
							ESX.TriggerServerCallback('wieczorGarages:putVehicle', function(done)
								if done then
									while DoesEntityExist(veh) do
										Citizen.Wait(10)
										DeleteEntity(veh)
									end
								else
									ESX.ShowNotification('Ten pojazd, ~r~nie należy do ciebie~w~!')
								end
							end, vehProperties)
						end
					else
						ESX.TriggerServerCallback("wieczorGarages:getVehicles", function(vehs)
							SetNuiFocus(true, true)
							SendNUIMessage({
								action = "openGarage",
								vehicles = vehs,
							})
						end)
					end
				end
			elseif CurrentZone == "vehicleoptions" then
				ESX.ShowHelpNotification("Naciśnij ~INPUT_PICKUP~ otworzyć zarządzanie pojazdami!")
				if IsControlJustReleased(0, 38) then
					OpenVehiclesOptions()
				end
			end
		else
			Citizen.Wait(500)
		end
	end
end)

RegisterNUICallback("close", function()
	SetNuiFocus(false, false)
end)

RegisterNUICallback("addToFavourite", function(data, cb)
	ESX.TriggerServerCallback("wieczorGarages:addToFavourites", function(result)
		if result == nil then
			ESX.ShowNotification("Nie znaleziono by te auto, należało do ciebie!")
		elseif result then
			ESX.ShowNotification("Dodano auto o rejestracji "..data.plate.." do ulubionych!")
		elseif not result then
			ESX.ShowNotification("Usunięto auto o rejestracji "..data.plate.." z ulubionych!")
		end
	end, data.plate)
end)

RegisterNUICallback("deleteVehicle", function(data, cb)
	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'garagesdeletervehicle', {
		title    = ' Czy napewno chcesz <b style="color:crimson">usunąć auto</b> o rejestracji: <b>'..data.plate..'</b> ',
		align    = 'center',
		elements = {
			{label = "NIE", value = "nie"},
			{label = "NIE", value = "nie"},
			{label = "TAK", value = "tak"},
			{label = "NIE", value = "nie"},
		}
	}, function(data2, menu2)
		if data2.current.value == "nie" then
			menu2.close()
		elseif data2.current.value == "tak" then
			menu2.close()
			ESX.TriggerServerCallback("wieczorGarages:deleteVehicle", function(res)
				if res then
					ESX.ShowNotification("Pomyślnie usunięto auto o numerze rejestracji "..data.plate.."!")
				else
					ESX.ShowNotification("Nie udało się usunąć auta o tym numerze rejestracji!")
				end
			end, data.plate)
		end
	end, function(data2, menu2)
		menu2.close()
	end)
end)

RegisterNUICallback("towVehicle", function(data, cb)
	ESX.TriggerServerCallback("wieczorGarages:towVehicle", function(result)
		if result then
			ESX.ShowNotification("Trwa odholowywanie pojazdu...")
			Wait(2500)
			if MyVehicles[data.plate] then
				ESX.ShowNotification("Nie udało się odholować samochodu!")
			else
				TriggerServerEvent("wieczorGarages:towVehicle", data.plate)
				ESX.ShowNotification("Odholowano samochód o rejestracji "..data.plate)
			end
		elseif not result then
			ESX.ShowNotification("Nie udało się odholować samochodu!")
		elseif result == nil then
			ESX.ShowNotification("Nie znaleziono pojazdu o takiej rejestracji!")
		end
	end, data.plate)
end)

RegisterNUICallback("pulloutVehicle", function(data, cb)
	ESX.TriggerServerCallback("wieczorGarages:pulloutVehicle", function(props, boost)
		local playerPed = PlayerPedId()
		local coords = GetEntityCoords(playerPed)
		local heading = GetEntityHeading(playerPed)
		ESX.Game.SpawnVehicle(props.model, coords, heading, function(veh)
			TaskWarpPedIntoVehicle(playerPed, veh, -1)
			ESX.Game.SetVehicleProperties(veh, props)
			SetVehicleEngineHealth(veh, props.engineHealth)
			SetVehicleBodyHealth(veh, props.bodyHealth)
			SetEntityAsMissionEntity(veh, true, true)
			SetVehicleHasBeenOwnedByPlayer(veh, true)
			local localVehPlate = string.lower(GetVehicleNumberPlateText(veh))
			TriggerEvent('ls:dodajklucze2', localVehPlate)
			Citizen.InvokeNative(0x10D373323E5B9C0D)
			if boost == 1 then
				SetVehicleEnginePowerMultiplier(veh, 50.0)
			end
		end)
	end, data.plate)
end)

RegisterNetEvent('wieczorGarages:findVehicle')
AddEventHandler('wieczorGarages:findVehicle', function(plate, owner)
    local vehicles = ESX.Game.GetVehicles()
    for _, vehicle in ipairs(vehicles) do
        local vehiclePlate = GetVehicleNumberPlateText(vehicle, true)
        if type(vehiclePlate) == 'string' then
            vehiclePlate = vehiclePlate:gsub("%s$", "")
			if vehiclePlate == plate then
				local attempt = 0 
				while not NetworkHasControlOfEntity(vehicle) and attempt < 100 and DoesEntityExist(vehicle) do
					Citizen.Wait(100)
					NetworkRequestControlOfEntity(vehicle)
					attempt = attempt + 1
				end
				if DoesEntityExist(vehicle) and NetworkHasControlOfEntity(vehicle) then
					if GetVehicleNumberOfPassengers(vehicle) > 0 or not IsVehicleSeatFree(vehicle, -1) then
						TriggerServerEvent('wieczorGarages:setVehicleBusy', plate, owner)
					else
						ESX.Game.DeleteVehicle(vehicle)
					end
				end
                break
            end
        end
    end
end)

RegisterNetEvent('wieczorGarages:setVehicleBusy')
AddEventHandler('wieczorGarages:setVehicleBusy', function(plate)
	MyVehicles[plate] = true
end)

RegisterCommand("clearwczrrfr", function()
	ESX.UI.Menu.CloseAll()
end)

function OpenVehiclesOptions()
	local elements = {}
	ESX.TriggerServerCallback("wieczorGarages:GetPlayerAllVehicles", function(vehicles)
		local elements = {
			head = {'Nazwa', 'Rejestracja', 'Współwłaściciel 1', 'Współwłaściciel 2', "Akcje"},
			rows = {}
		}
		local actions = ""
		for k,v in pairs(vehicles) do
			local actions = ""
			if v.co_owner ~= nil then
				actions = actions.." {{" .. 'Usuń współwłaściciela 1' .. "|deletecoowner1}}"
			else
				actions = actions.." {{" .. 'Dodaj współwłaściciela 1' .. "|addcoowner1}}"
			end
			if v.co_owner2 ~= nil then
				actions = actions.." {{" .. 'Usuń współwłaściciela 2' .. "|deletecoowner2}}"
			else
				actions = actions.." {{" .. 'Dodaj współwłaściciela 2' .. "|addcoowner2}}"
			end
			table.insert(elements.rows, {
				data = v,
				cols = {
					v.vehicleData.name,
					v.plate, 
					v.co_owner or "",
					v.co_owner2 or "",
					actions,
				}
			})
		end
		ESX.UI.Menu.Open('list', GetCurrentResourceName(), 'vehicles_options', elements, function(data, menu)
			local vehicledata = data.data
			if data.value == 'addcoowner1' then
				local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
				if closestPlayer ~= -1 and closestDistance <= 3.0 then
					menu.close()
					ESX.TriggerServerCallback("wieczorGarages:addVehicleCo_Owner1", function(res)
						if res == 1 then
							ESX.ShowNotification("Nie posiadasz dostępu do tego pojazdu!")
						elseif res == 2 then
							ESX.ShowNotification("Nie jesteś właścicielem tego pojazdu!")
						elseif res == 3 then
							ESX.ShowNotification("Posiadasz już zajęte miejsce współwłaściciela!")
						elseif res == 4 then
							ESX.ShowNotification("Pomyślnie ustanowiono współwłaściciela ["..GetPlayerServerId(closestPlayer).."] dla pojazdu o rejestracji: "..vehicledata.plate.."!")
						elseif res == 5 then
							ESX.ShowNotification("Ta osoba jest już 2 współwłaścicielem!")
						end
					end, vehicledata.plate, GetPlayerServerId(closestPlayer))
				else
					ESX.ShowNotification("~r~Brak osób w pobliżu")
				end
			elseif data.value == 'deletecoowner1' then
				menu.close()
				ESX.TriggerServerCallback("wieczorGarages:removeVehicleCo_Owner1", function(res)
					if res == 1 then
						ESX.ShowNotification("Nie posiadasz dostępu do tego pojazdu!")
					elseif res == 2 then
						ESX.ShowNotification("Nie jesteś właścicielem tego pojazdu!")
					elseif res == 4 then
						ESX.ShowNotification("Pomyślnie usunięto współwłaściciela ["..vehicledata.co_owner.."] dla pojazdu o rejestracji: "..vehicledata.plate.."!")
					end
				end, vehicledata.plate, vehicledata.co_owner, vehicledata.co_digit)
			elseif data.value == 'addcoowner2' then
				local closestPlayer, closestDistance = ESX.Game.GetClosestPlayer()
				if closestPlayer ~= -1 and closestDistance <= 3.0 then
					menu.close()
					ESX.TriggerServerCallback("wieczorGarages:addVehicleCo_Owner2", function(res)
						if res == 1 then
							ESX.ShowNotification("Nie posiadasz dostępu do tego pojazdu!")
						elseif res == 2 then
							ESX.ShowNotification("Nie jesteś właścicielem tego pojazdu!")
						elseif res == 3 then
							ESX.ShowNotification("Posiadasz już zajęte miejsce współwłaściciela!")
						elseif res == 4 then
							ESX.ShowNotification("Pomyślnie ustanowiono współwłaściciela ["..GetPlayerServerId(closestPlayer).."] dla pojazdu o rejestracji: "..vehicledata.plate.."!")
						elseif res == 5 then
							ESX.ShowNotification("Ta osoba jest już 1 współwłaścicielem!")
						end
					end, vehicledata.plate, GetPlayerServerId(closestPlayer))
				else
					ESX.ShowNotification("~r~Brak osób w pobliżu")
				end
			elseif data.value == 'deletecoowner2' then
				menu.close()
				ESX.TriggerServerCallback("wieczorGarages:removeVehicleCo_Owner2", function(res)
					if res == 1 then
						ESX.ShowNotification("Nie posiadasz dostępu do tego pojazdu!")
					elseif res == 2 then
						ESX.ShowNotification("Nie jesteś właścicielem tego pojazdu!")
					elseif res == 4 then
						ESX.ShowNotification("Pomyślnie usunięto współwłaściciela ["..vehicledata.co_owner2.."] dla pojazdu o rejestracji: "..vehicledata.plate.."!")
					end
				end, vehicledata.plate, vehicledata.co_owner2, vehicledata.co_digit2)
			end	
		end, function(data, menu)
			menu.close()
		end)
	end)
end