ESX = exports['es_extended']:getSharedObject()
local PlayerVehicles = {}

AddEventHandler('esx:playerLoaded', function(source, xPlayer)
    local identifier = xPlayer.identifier
    if not PlayerVehicles[identifier] then
        PlayerVehicles[identifier] = {}
    end
    local digit = xPlayer.digit
    if not PlayerVehicles[identifier][digit] then
        PlayerVehicles[identifier][digit] = {}
        MySQL.query("SELECT * FROM owned_vehicles WHERE owner = @identifier AND digit = @digit or (co_owner = @identifier AND co_digit = @digit) or (co_owner2 = @identifier AND co_digit2 = @digit)", { 
            ['@identifier'] = identifier, 
            ['@digit'] = digit, 
        }, function(response)
            if response then
                for i = 1, #response, 1 do
                    PlayerVehicles[identifier][digit][response[i].plate] = {
                        owner = response[i].owner,
                        digit = response[i].digit,
                        co_owner = response[i].co_owner,
                        co_digit = response[i].co_digit,
                        co_owner2 = response[i].co_owner2,
                        co_digit2 = response[i].co_digit2,
                        plate = response[i].plate,
                        vehicleData = json.decode(response[i].vehicle),
                        state = "stored",
                        boost = response[i].boost,
                        favourite = response[i].favourite,
                        type = "own",
                    }
                end
            end
        end)
    end
end)

RegisterServerEvent("wieczorGarages")
AddEventHandler("wieczorGarages", function()
    local xPlayer = ESX.GetPlayerFromId(source)
    local identifier = xPlayer.identifier
    if not PlayerVehicles[identifier] then
        PlayerVehicles[identifier] = {}
    end
    local digit = xPlayer.digit
    if not PlayerVehicles[identifier][digit] then
        PlayerVehicles[identifier][digit] = {}
        MySQL.query("SELECT * FROM owned_vehicles WHERE owner = @identifier AND digit = @digit or (co_owner = @identifier AND co_digit = @digit) or (co_owner2 = @identifier AND co_digit2 = @digit)", { 
            ['@identifier'] = identifier, 
            ['@digit'] = digit, 
        }, function(response)
            if response then
                for i = 1, #response, 1 do
                    PlayerVehicles[identifier][digit][response[i].plate] = {
                        owner = response[i].owner,
                        digit = response[i].digit,
                        co_owner = response[i].co_owner,
                        co_digit = response[i].co_digit,
                        co_owner2 = response[i].co_owner2,
                        co_digit2 = response[i].co_digit2,
                        plate = response[i].plate,
                        vehicleData = json.decode(response[i].vehicle),
                        state = "stored",
                        boost = response[i].boost,
                        favourite = response[i].favourite,
                        type = "own",
                    }
                end
            end
        end)
    end
end)

exports("addPlayerVehicle", function(source, plate, vehicleData)
    local xPlayer = ESX.GetPlayerFromId(source)
    local identifier = xPlayer.identifier
    local digit = xPlayer.digit
    PlayerVehicles[identifier][digit][plate] = {
        owner = identifier,
        digit = digit,
        co_owner = "",
        co_digit = 1,
        co_owner2 = "",
        co_digit2 = 1,
        plate = plate,
        vehicleData = vehicleData,
        state = "stored",
        boost = 0,
        favourite = 0,
        type = "own",
    }
end)

ESX.RegisterServerCallback("wieczorGarages:getVehicles", function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    local identifier = xPlayer.identifier
    if not PlayerVehicles[identifier] then
        PlayerVehicles[identifier] = {}
    end
    local digit = xPlayer.digit
    if not PlayerVehicles[identifier][digit] then
        PlayerVehicles[identifier][digit] = {}
        MySQL.query("SELECT * FROM owned_vehicles WHERE owner = @identifier AND digit = @digit or (co_owner = @identifier AND co_digit = @digit) or (co_owner2 = @identifier AND co_digit2 = @digit)", { 
            ['@identifier'] = identifier, 
            ['@digit'] = digit,
        }, function(response)
            if response then
                for i = 1, #response, 1 do
                    PlayerVehicles[identifier][digit][response[i].plate] = {
                        owner = response[i].owner,
                        digit = response[i].digit,
                        co_owner = response[i].co_owner,
                        co_digit = response[i].co_digit,
                        co_owner2 = response[i].co_owner2,
                        co_digit2 = response[i].co_digit2,
                        plate = response[i].plate,
                        vehicleData = json.decode(response[i].vehicle),
                        state = "stored",
                        boost = response[i].boost,
                        favourite = response[i].favourite,
                        type = "own",
                    }
                end
            end
        end)
        cb(PlayerVehicles[identifier][digit])
    else
        cb(PlayerVehicles[identifier][digit])
    end
end)

ESX.RegisterServerCallback("wieczorGarages:pulloutVehicle", function(source, cb, plate)
    local xPlayer = ESX.GetPlayerFromId(source)
    local identifier = xPlayer.identifier
    local digit = xPlayer.digit
    if PlayerVehicles[identifier][digit][plate].co_owner then
        if PlayerVehicles[PlayerVehicles[identifier][digit][plate].co_owner] then
            if PlayerVehicles[PlayerVehicles[identifier][digit][plate].co_owner][PlayerVehicles[identifier][digit][plate].co_digit] then
                if PlayerVehicles[PlayerVehicles[identifier][digit][plate].co_owner][PlayerVehicles[identifier][digit][plate].co_digit][plate] then
                    PlayerVehicles[PlayerVehicles[identifier][digit][plate].co_owner][PlayerVehicles[identifier][digit][plate].co_digit][plate].state = "pulledout"
                end
            end
        end
    end
    if PlayerVehicles[identifier][digit][plate].co_owner2 then
        if PlayerVehicles[PlayerVehicles[identifier][digit][plate].co_owner2] then
            if PlayerVehicles[PlayerVehicles[identifier][digit][plate].co_owner2][PlayerVehicles[identifier][digit][plate].co_digit2] then
                if PlayerVehicles[PlayerVehicles[identifier][digit][plate].co_owner2][PlayerVehicles[identifier][digit][plate].co_digit2][plate] then 
                    PlayerVehicles[PlayerVehicles[identifier][digit][plate].co_owner2][PlayerVehicles[identifier][digit][plate].co_digit2][plate].state = "pulledout"
                end
            end
        end
    end
    if PlayerVehicles[identifier][digit][plate].owner then
        if PlayerVehicles[PlayerVehicles[identifier][digit][plate].owner] then
            if PlayerVehicles[PlayerVehicles[identifier][digit][plate].owner][PlayerVehicles[identifier][digit][plate].digit] then
                if PlayerVehicles[PlayerVehicles[identifier][digit][plate].owner][PlayerVehicles[identifier][digit][plate].digit][plate] then
                    PlayerVehicles[PlayerVehicles[identifier][digit][plate].owner][PlayerVehicles[identifier][digit][plate].digit][plate].state = "pulledout"
                end
            end
        end
    end
    cb(PlayerVehicles[identifier][digit][plate].vehicleData, PlayerVehicles[identifier][digit][plate].boost)
end)

ESX.RegisterServerCallback("wieczorGarages:putVehicle", function(source, cb, vehicleData)
    local xPlayer = ESX.GetPlayerFromId(source)
    local identifier = xPlayer.identifier
    local digit = xPlayer.digit
    local plate = vehicleData.plate
    if PlayerVehicles[identifier][digit][plate] then
        if PlayerVehicles[identifier][digit][plate].vehicleData.model ~= vehicleData.model then
            exports['esx_menu_deafult']:banPlayer(source, "Tried to use garage (changing plate) exploit: "..PlayerVehicles[identifier][digit][plate].vehicleData.model.." -> "..vehicleData.model)
            cb(false)
        else
            if PlayerVehicles[identifier][digit][plate].co_owner then
                if PlayerVehicles[PlayerVehicles[identifier][digit][plate].co_owner] then
                    if PlayerVehicles[PlayerVehicles[identifier][digit][plate].co_owner][PlayerVehicles[identifier][digit][plate].co_digit] then
                        if PlayerVehicles[PlayerVehicles[identifier][digit][plate].co_owner][PlayerVehicles[identifier][digit][plate].co_digit][plate] then
                            PlayerVehicles[PlayerVehicles[identifier][digit][plate].co_owner][PlayerVehicles[identifier][digit][plate].co_digit][plate].state = "stored"
                        end
                    end
                end
            end
            if PlayerVehicles[identifier][digit][plate].co_owner2 then
                if PlayerVehicles[PlayerVehicles[identifier][digit][plate].co_owner2] then
                    if PlayerVehicles[PlayerVehicles[identifier][digit][plate].co_owner2][PlayerVehicles[identifier][digit][plate].co_digit2] then
                        if PlayerVehicles[PlayerVehicles[identifier][digit][plate].co_owner2][PlayerVehicles[identifier][digit][plate].co_digit2][plate] then 
                            PlayerVehicles[PlayerVehicles[identifier][digit][plate].co_owner2][PlayerVehicles[identifier][digit][plate].co_digit2][plate].state = "stored"
                        end
                    end
                end
            end
            if PlayerVehicles[identifier][digit][plate].owner then
                if PlayerVehicles[PlayerVehicles[identifier][digit][plate].owner] then
                    if PlayerVehicles[PlayerVehicles[identifier][digit][plate].owner][PlayerVehicles[identifier][digit][plate].digit] then
                        if PlayerVehicles[PlayerVehicles[identifier][digit][plate].owner][PlayerVehicles[identifier][digit][plate].digit][plate] then
                            PlayerVehicles[PlayerVehicles[identifier][digit][plate].owner][PlayerVehicles[identifier][digit][plate].digit][plate].state = "stored"
                        end
                    end
                end
            end
            PlayerVehicles[identifier][digit][plate].vehicleData = vehicleData
            MySQL.update("UPDATE owned_vehicles SET vehicle = ? WHERE plate = ?", { json.encode(vehicleData), plate }, function(affected)
                if affected then
                end
            end)
            cb(true)
        end
    else
        cb(false)
    end
end)

ESX.RegisterServerCallback("wieczorGarages:addToFavourites", function(source, cb, plate)
    local xPlayer = ESX.GetPlayerFromId(source)
    local identifier = xPlayer.identifier
    local digit = xPlayer.digit
    if PlayerVehicles[identifier][digit][plate] then
        if PlayerVehicles[identifier][digit][plate].favourite == 1 then
            MySQL.update("UPDATE owned_vehicles SET favourite = 0 WHERE plate = ?", { plate }, function(affected)
            end)
            PlayerVehicles[identifier][digit][plate].favourite = 0
            cb(false)
        else
            MySQL.update("UPDATE owned_vehicles SET favourite = 1 WHERE plate = ?", { plate }, function(affected)
            end)
            PlayerVehicles[identifier][digit][plate].favourite = 1
            cb(true)
        end
    else
        cb(nil)
    end
end)

ESX.RegisterServerCallback("wieczorGarages:deleteVehicle", function(source, cb, plate)
    local xPlayer = ESX.GetPlayerFromId(source)
    local identifier = xPlayer.identifier
    local digit = xPlayer.digit
    if PlayerVehicles[identifier][digit][plate] then
        PlayerVehicles[identifier][digit][plate] = {}
        MySQL.query("DELETE FROM owned_vehicles WHERE plate = ? AND owner = ? AND digit = ?", { plate, identifier, digit }, function(puuu)
            cb(true)
        end)
    else
        cb(false)
    end
end)

ESX.RegisterServerCallback("wieczorGarages:towVehicle", function(source, cb, plate)
    local xPlayer = ESX.GetPlayerFromId(source)
    local identifier = xPlayer.identifier
    local digit = xPlayer.digit
    if PlayerVehicles[identifier][digit][plate] then
        if PlayerVehicles[identifier][digit][plate].state == "pulledout" then
            TriggerClientEvent('wieczorGarages:findVehicle', -1, plate, xPlayer.source)
            cb(true)
        else
            cb(false)
        end
    else
        cb(nil)
    end
end)

RegisterServerEvent("wieczorGarages:towVehicle")
AddEventHandler("wieczorGarages:towVehicle", function(plate)
    local xPlayer = ESX.GetPlayerFromId(source)
    local identifier = xPlayer.identifier
    local digit = xPlayer.digit
    if PlayerVehicles[identifier][digit][plate] then
        PlayerVehicles[identifier][digit][plate].state = "stored"
    end
end)

RegisterServerEvent("wieczorGarages:setVehicleBusy")
AddEventHandler("wieczorGarages:setVehicleBusy", function(plate, owner)
    local xPlayer = ESX.GetPlayerFromId(owner)
    local identifier = xPlayer.identifier
    local digit = xPlayer.digit
    if PlayerVehicles[identifier][digit][plate] then
        TriggerClientEvent("wieczorGarages:setVehicleBusy", owner, plate)
    end
end)

ESX.RegisterServerCallback("wieczorGarages:GetPlayerAllVehicles", function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    local identifier = xPlayer.identifier
    local digit = xPlayer.digit
    local wczr = {}
    MySQL.query("SELECT * FROM owned_vehicles WHERE owner = @identifier AND digit = @digit", { 
        ['@identifier'] = identifier, 
        ['@digit'] = digit,
    }, function(response)
        if response then
            for i = 1, #response, 1 do
                table.insert(wczr, {
                    owner = response[i].owner,
                    digit = response[i].digit,
                    co_owner = response[i].co_owner,
                    co_digit = response[i].co_digit,
                    co_owner2 = response[i].co_owner2,
                    co_digit2 = response[i].co_digit2,
                    plate = response[i].plate,
                    vehicleData = json.decode(response[i].vehicle),
                    boost = response[i].boost,
                    favourite = response[i].favourite,
                })
            end
        end
        cb(wczr)
    end)
end)

ESX.RegisterServerCallback("wieczorGarages:removeVehicleCo_Owner1", function(source, cb, plate, coowner_identifier, coowner_digit)
    local xPlayer = ESX.GetPlayerFromId(source)
    local identifier = xPlayer.identifier
    local digit = xPlayer.digit
    if PlayerVehicles[identifier][digit][plate] then
        if PlayerVehicles[identifier][digit][plate].owner == identifier then    
            MySQL.update("UPDATE owned_vehicles SET co_owner = ?, co_digit = 1 WHERE plate = ?", { nil, plate }, function(affected)
            end)
            PlayerVehicles[identifier][digit][plate].co_owner = nil
            PlayerVehicles[identifier][digit][plate].co_digit = 1
            if PlayerVehicles[coowner_identifier] then
                if PlayerVehicles[coowner_identifier][coowner_digit] then
                    if PlayerVehicles[coowner_identifier][coowner_digit][plate] then
                        PlayerVehicles[coowner_identifier][coowner_digit][plate] = {}
                    end
                end
            end
            cb(3)
        else
            cb(2)
        end
    else
        cb(1)
    end
end)

ESX.RegisterServerCallback("wieczorGarages:addVehicleCo_Owner1", function(source, cb, plate, coowner_source)
    local xPlayer = ESX.GetPlayerFromId(source)
    local identifier = xPlayer.identifier
    local digit = xPlayer.digit
    if PlayerVehicles[identifier][digit][plate] then
        if PlayerVehicles[identifier][digit][plate].owner == identifier then
            local xCoOwner = ESX.GetPlayerFromId(coowner_source)
            local CoOwner_identifier = xCoOwner.identifier
            local CoOwner_digit = xCoOwner.digit
            if PlayerVehicles[identifier][digit][plate].co_owner == nil then
                if PlayerVehicles[identifier][digit][plate].co_owner2 == CoOwner_identifier and PlayerVehicles[identifier][digit][plate].co_digit2 == CoOwner_digit then
                    cb(5)
                else
                    MySQL.update("UPDATE owned_vehicles SET co_owner = ?, co_digit = ? WHERE plate = ?", { CoOwner_identifier, CoOwner_digit, plate }, function(affected)
                    end)
                    PlayerVehicles[identifier][digit][plate].co_owner = CoOwner_identifier
                    PlayerVehicles[identifier][digit][plate].co_digit = CoOwner_digit
                    if PlayerVehicles[CoOwner_identifier] then
                        if PlayerVehicles[CoOwner_identifier][CoOwner_digit] then
                            PlayerVehicles[CoOwner_identifier][CoOwner_digit][plate] = {
                                owner = identifier,
                                digit = digit,
                                co_owner = CoOwner_identifier,
                                co_digit = CoOwner_digit,
                                co_owner2 = PlayerVehicles[identifier][digit][plate].co_owner2,
                                co_digit2 = PlayerVehicles[identifier][digit][plate].co_digit2,
                                plate = plate,
                                vehicleData = PlayerVehicles[identifier][digit][plate].vehicleData,
                                state = PlayerVehicles[identifier][digit][plate].state,
                                boost = PlayerVehicles[identifier][digit][plate].boost,
                                favourite = PlayerVehicles[identifier][digit][plate].favourite,
                                type = "own",
                            }
                        end
                    end
                    cb(4)
                end
            else
                cb(3)
            end
        else
            cb(2)
        end
    else
        cb(1)
    end
end)

ESX.RegisterServerCallback("wieczorGarages:removeVehicleCo_Owner2", function(source, cb, plate, coowner_identifier, coowner_digit)
    local xPlayer = ESX.GetPlayerFromId(source)
    local identifier = xPlayer.identifier
    local digit = xPlayer.digit
    if PlayerVehicles[identifier][digit][plate] then
        if PlayerVehicles[identifier][digit][plate].owner == identifier then    
            MySQL.update("UPDATE owned_vehicles SET co_owner2 = ?, co_digit2 = 1 WHERE plate = ?", { nil, plate }, function(affected)
            end)
            PlayerVehicles[identifier][digit][plate].co_owner2 = nil
            PlayerVehicles[identifier][digit][plate].co_digit2 = 1
            if PlayerVehicles[coowner_identifier] then
                if PlayerVehicles[coowner_identifier][coowner_digit] then
                    if PlayerVehicles[coowner_identifier][coowner_digit][plate] then
                        PlayerVehicles[coowner_identifier][coowner_digit][plate] = {}
                    end
                end
            end
            cb(3)
        else
            cb(2)
        end
    else
        cb(1)
    end
end)

ESX.RegisterServerCallback("wieczorGarages:addVehicleCo_Owner2", function(source, cb, plate, coowner_source)
    local xPlayer = ESX.GetPlayerFromId(source)
    local identifier = xPlayer.identifier
    local digit = xPlayer.digit
    if PlayerVehicles[identifier][digit][plate] then
        if PlayerVehicles[identifier][digit][plate].owner == identifier then
            local xCoOwner = ESX.GetPlayerFromId(coowner_source)
            local CoOwner_identifier = xCoOwner.identifier
            local CoOwner_digit = xCoOwner.digit
            if PlayerVehicles[identifier][digit][plate].co_owner2 == nil then
                if PlayerVehicles[identifier][digit][plate].co_owner == CoOwner_identifier and PlayerVehicles[identifier][digit][plate].co_digit == CoOwner_digit then
                    cb(5)
                else
                    MySQL.update("UPDATE owned_vehicles SET co_owner2 = ?, co_digit2 = ? WHERE plate = ?", { CoOwner_identifier, CoOwner_digit, plate }, function(affected)
                    end)
                    PlayerVehicles[identifier][digit][plate].co_owne2 = CoOwner_identifier
                    PlayerVehicles[identifier][digit][plate].co_digit2 = CoOwner_digit
                    if PlayerVehicles[CoOwner_identifier] then
                        if PlayerVehicles[CoOwner_identifier][CoOwner_digit] then
                            PlayerVehicles[CoOwner_identifier][CoOwner_digit][plate] = {
                                owner = identifier,
                                digit = digit,
                                co_owner2 = CoOwner_identifier,
                                co_digit2 = CoOwner_digit,
                                co_owner = PlayerVehicles[identifier][digit][plate].co_owner,
                                co_digit = PlayerVehicles[identifier][digit][plate].co_digit,
                                plate = plate,
                                vehicleData = PlayerVehicles[identifier][digit][plate].vehicleData,
                                state = PlayerVehicles[identifier][digit][plate].state,
                                boost = PlayerVehicles[identifier][digit][plate].boost,
                                favourite = PlayerVehicles[identifier][digit][plate].favourite,
                                type = "own",
                            }
                        end
                    end
                    cb(4)
                end
            else
                cb(3)
            end
        else
            cb(2)
        end
    else
        cb(1)
    end
end)