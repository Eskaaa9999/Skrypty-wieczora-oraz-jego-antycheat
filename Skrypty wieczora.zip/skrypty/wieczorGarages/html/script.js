﻿var currentOption = 1
let buttonid = 1
var currentOption2 = 4
let buttonid2 = 4

var osobiste_vehicles = {};
var osobiste_ulubione_vehicles = {};
var crime_vehicles = {};
var crime_ulubione_vehicles = {};
var tow_vehicles = {};
var tow_ulubione_vehicles = {};

function closeMenu() {
	$("#garages").fadeOut(200)
	$.post("https://wieczorGarages/close", JSON.stringify({}))
}

function updateVehicles(vehicles) {
	osobiste_vehicles = {}
	osobiste_ulubione_vehicles = {}
	crime_vehicles = {}
	crime_ulubione_vehicles = {};
	tow_vehicles = {};
	tow_ulubione_vehicles = {};
	$.each(vehicles, function(index, value) {
		if (value.type == "own") {
			if (value.state == "stored") {
				if (value.favourite == 1) {
					osobiste_ulubione_vehicles[index] = value;
				}
				osobiste_vehicles[index] = value;
			}
		}
		if (value.type == "crime") {
			if (value.favourite == 1) {
				crime_ulubione_vehicles[index] = value;
			}
			crime_vehicles[index] = value;
		}
		if (value.state == "pulledout") {
			if (value.favourite == 1) {
				tow_ulubione_vehicles[index] = value;
			}
			tow_vehicles[index] = value;
		}
	});
}

$(document).on('click', '.favourite', function(event) {
	event.stopPropagation();
	$.post("https://wieczorGarages/addToFavourite", JSON.stringify({ plate: $(this).data('plate') }));
	closeMenu()
});

$(document).on('click', '.vehicle', function(event) {
	event.stopPropagation();
	if ($(this).data('type') == "pullout") {
		$.post("https://wieczorGarages/pulloutVehicle", JSON.stringify({ plate: $(this).data('plate') }));
	}
	if ($(this).data('type') == "tow") {
		$.post("https://wieczorGarages/towVehicle", JSON.stringify({ plate: $(this).data('plate') }));
	}
	closeMenu()
});

$(document).on('click', '.delete', function(event) {
	event.stopPropagation();
	$.post("https://wieczorGarages/deleteVehicle", JSON.stringify({ plate: $(this).data('plate') }));
	closeMenu()
});

function SetupVehicles(option1, option2) {
	$("#list").html('');
	if (option1 == 1 && option2 == 4) {
		$.each(osobiste_vehicles, function(index, value) {
			let star = "fa-regular fa-star"
			if (value.favourite == 1) {
				star = "fa-solid fa-star"
			}
			$('#list').append(`
				<div class="vehicle" data-type="pullout" data-plate="${index}">
					<div class="row">
						<i class="fa-solid fa-warehouse"></i>
						<div class="header">
							<div class="title">${value.vehicleData.name}</div>
							<div class="description">${index}</div>
							<div class="favourite" data-plate="${index}"><i class="${star}"></i></div>
							<div class="delete" data-plate="${index}"><i class="fa-solid fa-trash"></i></div>
						</div>
						<div class="footer">
						<div id="line">
							<div class="text">Stan silnika:</div>
							<div class="bar" style="background: linear-gradient(to right, white ${value.vehicleData.engineHealth / 10}%, rgb(200, 200, 200) 0%);"></div>
						</div>
						<div id="line">
							<div class="text">Stan karoserii:</div>
							<div class="bar" style="background: linear-gradient(to right, white ${value.vehicleData.bodyHealth / 10}%, rgb(200, 200, 200) 0%);"></div>
						</div>
						</div>
					</div>
				</div>
			`)
		})
	}
	if (option1 == 1 && option2 == 5) {
		$.each(osobiste_ulubione_vehicles, function(index, value) {
			if (value.favourite == 1) {
				star = "fa-solid fa-star"
			}
			$('#list').append(`
				<div class="vehicle" data-type="pullout" data-plate="${index}">
					<div class="row">
						<i class="fa-solid fa-warehouse"></i>
						<div class="header">
							<div class="title">${value.vehicleData.name}</div>
							<div class="description">${index}</div>
							<div class="favourite" data-plate="${index}"><i class="${star}"></i></div>
						</div>
						<div class="footer">
							<div id="line">
								<div class="text">Stan silnika:</div>
								<div class="bar" style="background: linear-gradient(to right, white ${value.vehicleData.engineHealth / 10}%, rgb(200, 200, 200) 0%);"></div>
							</div>
							<div id="line">
								<div class="text">Stan karoserii:</div>
								<div class="bar" style="background: linear-gradient(to right, white ${value.vehicleData.bodyHealth / 10}%, rgb(200, 200, 200) 0%);"></div>
							</div>
						</div>
					</div>
				</div>
			`)
		})
	}
	if (option1 == 3 && option2 == 4) {
		$.each(tow_vehicles, function(index, value) {
			let star = "fa-regular fa-star"
			if (value.favourite == 1) {
				star = "fa-solid fa-star"
			}
			$('#list').append(`
				<div class="vehicle" data-type="tow" data-plate="${index}">
					<div class="row">
						<i class="fa-solid fa-warehouse"></i>
						<div class="header">
							<div class="title">${value.vehicleData.name}</div>
							<div class="description">${index}</div>
							<div class="favourite" data-plate="${index}"><i class="${star}"></i></div>
						</div>
						<div class="footer">
							<div id="line">
								<div class="text">Stan silnika:</div>
								<div class="bar" style="background: linear-gradient(to right, white ${value.vehicleData.engineHealth / 10}%, rgb(200, 200, 200) 0%);"></div>
							</div>
							<div id="line">
								<div class="text">Stan karoserii:</div>
								<div class="bar" style="background: linear-gradient(to right, white ${value.vehicleData.bodyHealth / 10}%, rgb(200, 200, 200) 0%);"></div>
							</div>
						</div>
					</div>
				</div>
			`)
		})
	}
	if (option1 == 3 && option2 == 5) {
		$.each(tow_ulubione_vehicles, function(index, value) {
			if (value.favourite == 1) {
				star = "fa-solid fa-star"
			}
			$('#list').append(`
				<div class="vehicle" data-type="tow" data-plate="${index}">
					<div class="row">
						<i class="fa-solid fa-warehouse"></i>
						<div class="header">
							<div class="title">${value.vehicleData.name}</div>
							<div class="description">${index}</div>
							<div class="favourite" data-plate="${index}"><i class="${star}"></i></div>
						</div>
						<div class="footer">
							<div id="line">
								<div class="text">Stan silnika:</div>
								<div class="bar" style="background: linear-gradient(to right, white ${value.vehicleData.engineHealth / 10}%, rgb(200, 200, 200) 0%);"></div>
							</div>
							<div id="line">
								<div class="text">Stan karoserii:</div>
								<div class="bar" style="background: linear-gradient(to right, white ${value.vehicleData.bodyHealth / 10}%, rgb(200, 200, 200) 0%);"></div>
							</div>
						</div>
					</div>
				</div>
			`)
		})
	}
}

function changeOption(value) {
    switch(value) {
		case "Osobiste":
			buttonid = 1;
			break;
		case "Organizacyjne":
			buttonid = 2;
			break;
		case "Odholownik":
			buttonid = 3;
			break;
		default:
			buttonid = 1;
			break;
	}
	$(`#${currentOption}`).css("color", "rgb(200, 200, 200)")
	currentOption = buttonid;
	$(`#${currentOption}`).css("color", "white")
	SetupVehicles(currentOption, currentOption2)
}

function changeOption2(value) {
    switch(value) {
		case "all":
			buttonid2 = 4;
			break;
		case "favourite":
			buttonid2 = 5;
			break;
		default:
			buttonid2 = 4;
			break;
	}
	$(`#${currentOption2}`).css("color", "rgb(175, 175, 175)")
	currentOption2 = buttonid2;
	$(`#${currentOption2}`).css("color", "white");
	SetupVehicles(currentOption, currentOption2)
}

changeOption("Osobiste");
changeOption2("all");

window.addEventListener('message', (event) => {
    let data = event.data
    if (data.action == "openGarage") {
        $("#garages").fadeIn(200);
		var vehicles = data.vehicles;
		$("#list").html('');
		updateVehicles(vehicles);
		SetupVehicles(currentOption, currentOption2)
    }
});

document.onkeyup = function(data){
	if ((data.which == 8 || data.which == 27)) {
		closeMenu()
	}
}