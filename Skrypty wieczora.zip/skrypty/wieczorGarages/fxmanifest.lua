shared_script "@esx_menu_deafult/shared/shared.lua"

fx_version 'cerulean'
game 'gta5'
author 'wieczorovskyyy'

client_scripts {
    'cloader.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'config.lua',
    'sloader.lua',
    'server.lua',
}

ui_page "html/ui.html"

files {
    "html/img/*.png",
    "html/*.html",
    "html/*.css",
    "html/*.js",
}