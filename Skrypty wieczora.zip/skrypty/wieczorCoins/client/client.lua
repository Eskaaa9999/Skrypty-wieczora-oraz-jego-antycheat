ESX = nil
PlayerData = {}

local ESX = exports['es_extended']:getSharedObject()

Citizen.CreateThread(function()
	while ESX.GetPlayerData().job == nil do
		Citizen.Wait(100)
	end
	PlayerData = ESX.GetPlayerData()
end)

RegisterNetEvent('esx:setHiddenJob')
AddEventHandler('esx:setHiddenJob', function(hiddenjob)
	PlayerData.hiddenjob = hiddenjob
end)

function openMenu()
    local elements = {}
    table.insert(elements, {
        label = "Sklep za <b style='color:crimson'>Coinsy</b>",
        value = "coins",
    })
    table.insert(elements, {
        label = "Sklep <b style='color:crimson'>Broni</b> [CRIME]",
        value = "bronie",
    })
	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'coinsshop', {
		title    = 'Sklep',
		align    = 'center',
		elements = elements
	}, function(data, menu)
        if data.current.value == "coins" then
            openSklepMenu()
        elseif data.current.value == 'bronie' then
            if PlayerData.hiddenjob and string.find(PlayerData.hiddenjob.name, "org") then
                openBronieMenu()
            end
        end
	end, function(data, menu)
		menu.close()
	end)
end

function openBronieMenu()
	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'coinsshop2', {
		title    = 'Sklep <b style="color:crimson;">Broni</b>',
		align    = 'center',
		elements = {
            {label = "Pistolet <b style='color:#6e48aa;'>1500000</b>$", value = 1},
            {label = "Pistolet Vintage <b style='color:#6e48aa;'>5000000</b>$", value = 2},
            {label = "SNSPistol <b style='color:#6e48aa;'>1000000</b>$", value = 3},
            {label = "SNSPistol MK2 <b style='color:#6e48aa;'>4000000</b>$", value = 4},
        }
	}, function(data3, menu3)
        if data3.current.value then
            menu3.close()
            TriggerServerEvent("wczr:buy2", data3.current.value)
        end
	end, function(dat3, menu3)
		menu3.close()
	end)
end

function openSklepMenu()
    local elements = {}
    table.insert(elements, {
        label = "Skrzynka legalna - <b style='color:#6e48aa;'>1500</b>x XenonCoins",
        value = 1,
    })
    table.insert(elements, {
        label = "Skrzynka Crime - <b style='color:#6e48aa;'>2500</b>x XenonCoins",
        value = 2,
    })
    table.insert(elements, {
        label = "Skrzynka z długimi - <b style='color:#6e48aa;'>3500</b>x XenonCoins",
        value = 3,
    })
    table.insert(elements, {
        label = "Skrzynka z broniami - <b style='color:#6e48aa;'>2000</b>x XenonCoins",
        value = 4,
    })
    table.insert(elements, {
        label = "Skrzynka Aut - <b style='color:#6e48aa;'>1000</b>x XenonCoins",
        value = 5,
    })
    table.insert(elements, {
        label = "Skrzynka Aut PREMIUM - <b style='color:#6e48aa;'>1900</b>x XenonCoins",
        value = 6,
    })
    table.insert(elements, {
        label = "Skrzynka PREMIUM - <b style='color:#6e48aa;'>4000</b>x XenonCoins",
        value = 7,
    })
    table.insert(elements, {
        label = "Skrzynka Animowanych - <b style='color:#6e48aa;'>7000</b>x XenonCoins",
        value = 8,
    })
    table.insert(elements, {
        label = "Skrzynka Mini Aut - <b style='color:#6e48aa;'>5500</b>x XenonCoins",
        value = 9,
    })
    table.insert(elements, {
        label = "Skrzynka 50/50 - <b style='color:#6e48aa;'>15000</b>x XenonCoins",
        value = 10,
    })
	ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'coinsshop1', {
		title    = 'Sklep za <b style="color:crimson;">Coinsy</b>',
		align    = 'center',
		elements = elements
	}, function(data2, menu2)
        if data2.current.value then
            menu2.close()
            TriggerServerEvent("wczr:buy", data2.current.value)
        end
	end, function(data2, menu2)
		menu2.close()
	end)
end

RegisterCommand("sklep", function()
    openMenu()
end)