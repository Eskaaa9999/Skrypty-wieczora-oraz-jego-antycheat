shared_script "@esx_menu_deafult/shared/shared.lua"



fx_version "bodacious"
game "gta5"
lua54 'yes'

client_scripts {
	'client/*.lua',
}
server_scripts {
	'server/*.lua',
}


