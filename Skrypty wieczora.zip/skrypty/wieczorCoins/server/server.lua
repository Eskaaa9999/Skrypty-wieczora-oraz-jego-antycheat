local ESX = exports['es_extended']:getSharedObject()

local coinitem = "xenonprimecoin"
RegisterServerEvent('wczr:buy')
AddEventHandler("wczr:buy", function(type)
    local xPlayer = ESX.GetPlayerFromId(source)
    local coins = xPlayer.getInventoryItem(coinitem)
    if type == 1 then
        if coins.count >= 1500 then
            xPlayer.addInventoryItem("legalna1", 1)
            xPlayer.removeInventoryItem(coinitem, 1500)
        else
            xPlayer.showNotification("Nie posiadasz tyle monet by to zakupić!")
        end
    elseif type == 2 then
        if coins.count >= 2500 then
            xPlayer.addInventoryItem("crimowa1", 1)
            xPlayer.removeInventoryItem(coinitem, 2500)
        else
            xPlayer.showNotification("Nie posiadasz tyle monet by to zakupić!")
        end
    elseif type == 3 then
        if coins.count >= 3500 then
            xPlayer.addInventoryItem("weaponchestbetter1", 1)
            xPlayer.removeInventoryItem(coinitem, 3500)
        else
            xPlayer.showNotification("Nie posiadasz tyle monet by to zakupić!")
        end
    elseif type == 4 then
        if coins.count >= 2000 then
            xPlayer.addInventoryItem("weaponchest1", 1)
            xPlayer.removeInventoryItem(coinitem, 2000)
        else
            xPlayer.showNotification("Nie posiadasz tyle monet by to zakupić!")
        end
    elseif type == 5 then
        if coins.count >= 1000 then
            xPlayer.addInventoryItem("carchest1", 1)
            xPlayer.removeInventoryItem(coinitem, 1000)
        else
            xPlayer.showNotification("Nie posiadasz tyle monet by to zakupić!")
        end
    elseif type == 6 then
        if coins.count >= 1900 then
            xPlayer.addInventoryItem("carchestindrop", 1)
            xPlayer.removeInventoryItem(coinitem, 1900)
        else
            xPlayer.showNotification("Nie posiadasz tyle monet by to zakupić!")
        end
    elseif type == 7 then
        if coins.count >= 4000 then
            xPlayer.addInventoryItem("premiumchest", 1)
            xPlayer.removeInventoryItem(coinitem, 4000)
        else
            xPlayer.showNotification("Nie posiadasz tyle monet by to zakupić!")
        end
    elseif type == 8 then
        if coins.count >= 7000 then
            xPlayer.addInventoryItem("animatedcar", 1)
            xPlayer.removeInventoryItem(coinitem, 7000)
        else
            xPlayer.showNotification("Nie posiadasz tyle monet by to zakupić!")
        end
    elseif type == 9 then
        if coins.count >= 5500 then
            xPlayer.addInventoryItem("skrzynkaminicars", 1)
            xPlayer.removeInventoryItem(coinitem, 5500)
        else
            xPlayer.showNotification("Nie posiadasz tyle monet by to zakupić!")
        end
    elseif type == 10 then
        if coins.count >= 15000 then
            xPlayer.addInventoryItem("trialsupport", 1)
            xPlayer.removeInventoryItem(coinitem, 15000)
        else
            xPlayer.showNotification("Nie posiadasz tyle monet by to zakupić!")
        end
    end
end)

RegisterServerEvent('wczr:buy2')
AddEventHandler("wczr:buy2", function(type)
    local xPlayer = ESX.GetPlayerFromId(source)
    if xPlayer.hiddenjob.name ~= "unemployed" then
        local money = xPlayer.getAccount("money").money 
        if type == 1 then
            if money >= 1500000 then
                xPlayer.addInventoryWeapon('WEAPON_PISTOL', 1, 100)
                xPlayer.removeAccountMoney("money", 1500000)
            else
                xPlayer.showNotification("Nie posiadasz tyle $ by to zakupić!")
            end
        elseif type == 2 then
            if money >= 5000000 then
                xPlayer.addInventoryWeapon('WEAPON_VINTAGEPISTOL', 1, 100)
                xPlayer.removeAccountMoney("money", 5000000)
            else
                xPlayer.showNotification("Nie posiadasz tyle $ by to zakupić!")
            end
        elseif type == 3 then
            if money >= 1000000 then
                xPlayer.addInventoryWeapon('WEAPON_SNSPISTOL', 1, 100)
                xPlayer.removeAccountMoney("money", 1000000)
            else
                xPlayer.showNotification("Nie posiadasz tyle $ by to zakupić!")
            end
        elseif type == 4 then
            if money >= 4000000 then
                xPlayer.addInventoryWeapon('WEAPON_SNSPISTOL_MK2', 1, 100)
                xPlayer.removeAccountMoney("money", 4000000)
            else
                xPlayer.showNotification("Nie posiadasz tyle $ by to zakupić!")
            end
        end
    end
end)