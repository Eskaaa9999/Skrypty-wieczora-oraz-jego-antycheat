ESX = exports['es_extended']:getSharedObject()

local killer = {}
RegisterNetEvent("esx:onPlayerDeath")
AddEventHandler("esx:onPlayerDeath", function(data)
    if data then
        if data.victim then
            if data.killedByPlayer then
                if killer[data.victim] ~= data.killerServerId then
                    if data.deathCause ~= `WEAPON_UNARMED` then
                        local xPlayer = ESX.GetPlayerFromId(data.killerServerId)
                        local xone = ESX.GetPlayerFromId(data.victim)
                        if xPlayer then
                            if data.victim then
                                xPlayer.addMoney(100000)
                                xPlayer.showNotification("Gratulacje! Dostałeś 100k za zabicie: "..GetPlayerName(data.victim).." ["..data.victim.."]!")
                                killer[data.victim] = data.killerServerId
                            end
                        end
                    end
                end
            end
        end
    end
end)

local starterpack_items = {
    {name = "coke_pooch", count = 500},
    {name = "radio", count = 500},
    {name = "clip", count = 100},
    {name = "carchest1", count = 1},
    {name = "crimowa1", count = 2},
}

local starterpack_weapons = {
    {name = "weapon_vintagepistol", powtorzen = 25},
    {name = "weapon_snspistol_mk2", powtorzen = 25},
}
--[[
RegisterCommand("givestarterpack", function(source, args, raw)
    local xPlayer = ESX.GetPlayerFromId(source)
    if args[1] ~= nil then
        if xPlayer.group == "best" then
            exports['xenon_logs']:SendLog(source, 'nadano starterpack organizacyjny dla '..args[1], 'starterpack', '3066993')
            for i = 1, #starterpack_items, 1 do
                Wait(500)
                TriggerEvent('esx_addoninventory:getSharedInventory', "society_"..args[1], function(inventory)
                    inventory.addItem(starterpack_items[i].name, starterpack_items[i].count)
                end)
            end
            for i = 1, #starterpack_weapons, 1 do
                Wait(1000)
                ESX.CreateDynamicItem({
                    name = starterpack_weapons[i].name,
                    label = ESX.GetWeaponLabel(starterpack_weapons[i].name),
                    type = 'weapon',
                    serial = false,
                    ammo = 0,
                }, function(data)					
                    if data then	
                        TriggerEvent('esx_addoninventory:getSharedInventory', "society_"..args[1], function(inventory)
                            inventory.addItem(data, 1)
                        end)					
                    end
                end)
            end
            xPlayer.showNotifcation("Nadano pomyślnie starterpack dla: "..args[1])
        end
    else
        xPlayer.showNotification("Nie podano organizacji!")
    end
end)]]