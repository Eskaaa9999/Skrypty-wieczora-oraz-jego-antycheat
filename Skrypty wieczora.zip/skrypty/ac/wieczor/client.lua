ESX = exports['es_extended']:getSharedObject()

function isCarBlacklisted(model)
	for k, v in pairs(Config.BlacklistedCars) do
		if model == GetHashKey(v) then
			return true
		end
	end
	return false
end

function CheckCar(car)
	if car then
		carModel = GetEntityModel(car)
		if isCarBlacklisted(carModel) then
            DeleteEntity(car)
		end
	end
end

function CheckWeapon(model)
    for k, v in pairs(Config.BlacklistedWeapons) do
		if model == GetHashKey(v) then
			return true
		end
	end
	return false
end

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(2500)
        CheckCar(GetVehiclePedIsIn(PlayerPedId(), false))
        x, y, z = table.unpack(GetEntityCoords(PlayerPedId(), true))
        for k, v in pairs(Config.BlacklistedCars) do
            CheckCar(GetClosestVehicle(x, y, z, 100.0, GetHashKey(v), 70))
        end
    end
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(500)
	    nothing, weapon = GetCurrentPedWeapon(PlayerPedId(), true)
		if CheckWeapon(weapon) then
			RemoveWeaponFromPed(PlayerPedId(), weapon)
		end
	end
end)

local started = false
RegisterNetEvent('playerSpawned')
AddEventHandler('playerSpawned', function()
    if not started then
        CreateThread(function()
            started = true
            while true do
                Wait(1)
                local ped = GetPlayerPed(-1)
                local cv, boneIndex = GetPedLastDamageBone(ped)
                if boneIndex == 39317 or boneIndex == 25260 or boneIndex == 27474 or boneIndex == 35731 or boneIndex == 19336 or boneIndex == 31086 then
                    started = false
                    ApplyDamageToPed(ped, 300, 1)
                    break
                end
            end
        end)
    end
end)

local Weapons = {
	'weapon_pistol',
	'weapon_pistol_mk2',
	'weapon_combatpistol',
	'weapon_appistol',
	'weapon_pistol50',
	'weapon_snspistol',
	'weapon_snspistol_mk2',
	'weapon_heavypistol',
	'weapon_vintagepistol',
	'weapon_revolver',
	'weapon_revolver_mk2',
	'weapon_doubleaction',
	'weapon_ceramicpistol',
	'weapon_navyrevolver',
}

helmet = false

RegisterNetEvent('playerSpawned')
AddEventHandler('playerSpawned', function()
    CreateThread(function()
        local headshot = false
        while true do
            Wait(0)
            local ped = GetPlayerPed(-1)
            local cv, boneIndex = GetPedLastDamageBone(ped)
            if boneIndex == 31086 and not headshot then
                if not helmet then
                    headshot = true
                    ApplyDamageToPed(ped, 300, 1)
                    break
                else
                    local g = GetEntityHealth(a)
                    local h = GetPedArmour(a)
                    if h > 0 then
                        givearmor = h - 50
                        if givearmor < 0 then
                            givearmor = 0
                        end
                        SetPedArmour(a, givearmor)
                        ClearEntityLastDamageEntity(a)
                    else
                        givehealth = g - 25
                        if givehealth <= 100 then
                            givehealth = 0
                        else
                            ClearEntityLastDamageEntity(a)
                        end
                        SetEntityHealth(a, givehealth)
                    end
                    break
                end
            end
        end
    end)
end)

RegisterNetEvent('playerSpawned')
AddEventHandler('playerSpawned', function()
    CreateThread(function()
        while true do
            Wait(15000)
            if GetPedPropIndex(PlayerPedId(), 0) == 39 and IsPedMale(PlayerPedId()) then
                helmet = true
            else
                helmet = false
            end
        end
    end)
end)