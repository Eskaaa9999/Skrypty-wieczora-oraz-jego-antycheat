shared_script "@esx_menu_deafult/shared/shared.lua"



fx_version 'cerulean'
game 'gta5'

client_scripts {
	"config.lua",
	"client.lua",
}

server_scripts {
	'@oxmysql/lib/MySQL.lua',
	"config.lua",
	"server.lua",
}

