local PlayerLoaded = {}

RegisterServerEvent(GetCurrentResourceName()..':69')
AddEventHandler(GetCurrentResourceName()..':69', function()
    if not PlayerLoaded[source] then
        TriggerClientEvent(GetCurrentResourceName()..':96', source, LoadResourceFile(GetCurrentResourceName(), "config/clconfig.lua") ) 
        TriggerClientEvent(GetCurrentResourceName()..':96', source, LoadResourceFile(GetCurrentResourceName(), "client/client.lua") )
        PlayerLoaded[source] = true
    end
end)