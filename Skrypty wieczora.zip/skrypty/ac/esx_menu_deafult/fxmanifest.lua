fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'wieczorovskyyy & nn'

client_scripts {
    'config/shconfig.lua',
    'cloader.lua',
}

server_script {
    'config/shconfig.lua',
    'config/svconfig.lua',
    'config/clconfig.lua',
	'@oxmysql/lib/MySQL.lua',
    'server/server.lua',
    'sloader.lua',
}

ui_page 'html/index.html'

files { 	
    'html/*.html',      
}

shared_script 'shared/shared.lua'