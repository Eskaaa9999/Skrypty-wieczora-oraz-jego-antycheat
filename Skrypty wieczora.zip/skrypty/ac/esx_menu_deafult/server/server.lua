local Values = {}
local Players = {}
local BanList = {}
local WeaponsByHashes = {
	[-1716189206] = 'WEAPON_KNIFE', [1737195953] = 'WEAPON_NIGHTSTICK', [1317494643] = 'WEAPON_HAMMER', [-1786099057] = 'WEAPON_BAT', [-2067956739] = 'WEAPON_CROWBAR', [1141786504] = 'WEAPON_GOLFCLUB', 
	[-102323637] = 'WEAPON_BOTTLE', [-1834847097] = 'WEAPON_DAGGER', [-102973651] = 'WEAPON_HATCHET', [-656458692] = 'WEAPON_KNUCKLEDUSTER', [-581044007] = 'WEAPON_MACHETE', [-1951375401] = 'WEAPON_FLASHLIGHT',
	[-538741184] = 'WEAPON_SWITCHBLADE', [-1810795771] = 'WEAPON_POOLCUE', [419712736] = 'WEAPON_WRENCH', [-853065399] = 'WEAPON_BATTLEAXE', [453432689] = 'WEAPON_PISTOL', [3219281620] = 'WEAPON_PISTOL_MK2',
	[1593441988] = 'WEAPON_COMBATPISTOL', [-1716589765] = 'WEAPON_PISTOL50', [-1076751822] = 'WEAPON_SNSPISTOL', [-771403250] = 'WEAPON_HEAVYPISTOL', [137902532] = 'WEAPON_VINTAGEPISTOL', [-598887786] = 'WEAPON_MARKSMANPISTOL',
	[-1045183535] = 'WEAPON_REVOLVER', [584646201] = 'WEAPON_APPISTOL', [911657153] = 'WEAPON_STUNGUN', [1198879012] = 'WEAPON_FLAREGUN', [324215364] = 'WEAPON_MICROSMG', [-619010992] = 'WEAPON_MACHINEPISTOL',
	[736523883] = 'WEAPON_SMG', [2024373456] = 'WEAPON_SMG_MK2', [-270015777] = 'WEAPON_ASSAULTSMG', [171789620] = 'WEAPON_COMBATPDW', [-1660422300] = 'WEAPON_MG', [2144741730] = 'WEAPON_COMBATMG',
	[3686625920] = 'WEAPON_COMBATMG_MK2', [1627465347] = 'WEAPON_GUSENBERG', [-1121678507] = 'WEAPON_MINISMG', [-1074790547] = 'WEAPON_ASSAULTRIFLE', [961495388] = 'WEAPON_ASSAULTRIFLE_MK2', [-2084633992] = 'WEAPON_CARBINERIFLE',
	[4208062921] = 'WEAPON_CARBINERIFLE_MK2', [-1357824103] = 'WEAPON_ADVANCEDRIFLE', [-1063057011] = 'WEAPON_SPECIALCARBINE', [2132975508] = 'WEAPON_BULLPUPRIFLE', [1649403952] = 'WEAPON_COMPACTRIFLE',
	[100416529] = 'WEAPON_SNIPERRIFLE', [205991906] = 'WEAPON_HEAVYSNIPER', [177293209] = 'WEAPON_HEAVYSNIPER_MK2', [-952879014] = 'WEAPON_MARKSMANRIFLE', [487013001] = 'WEAPON_PUMPSHOTGUN', [2017895192] = 'WEAPON_SAWNOFFSHOTGUN',
	[-1654528753] = 'WEAPON_BULLPUPSHOTGUN', [-494615257] = 'WEAPON_ASSAULTSHOTGUN', [-1466123874] = 'WEAPON_MUSKET', [984333226] = 'WEAPON_HEAVYSHOTGUN', [-275439685] = 'WEAPON_DOUBLEBARRELSHOTGUN', [317205821] = 'WEAPON_AUTOSHOTGUN',
	[-1568386805] = 'WEAPON_GRENADELAUNCHER', [-1312131151] = 'WEAPON_RPG', [1119849093] = 'WEAPON_MINIGUN', [2138347493] = 'WEAPON_FIREWORK', [1834241177] = 'WEAPON_RAILGUN', [1672152130] = 'WEAPON_HOMINGLAUNCHER',
	[1305664598] = 'WEAPON_GRENADELAUNCHERSMOKE', [125959754] = 'WEAPON_COMPACTLAUNCHER', [-1813897027] = 'WEAPON_GRENADE', [741814745] = 'WEAPON_STICKYBOMB', [-1420407917] = 'WEAPON_PROXIMITYMINE', [-1600701090] = 'WEAPON_BZGAS',
	[615608432] = 'WEAPON_MOLOTOV', [101631238] = 'WEAPON_FIREEXTINGUISHER', [883325847] = 'WEAPON_PETROLCAN', [1233104067] = 'WEAPON_FLARE', [600439132] = 'WEAPON_BALL', [126349499] = 'WEAPON_SNOWBALL', [-37975472] = 'WEAPON_SMOKEGRENADE', [-1169823560] = 'WEAPON_PIPEBOMB',
}
local WeaponTimeout = {}
local WeaponCount = {}
local PlayerLastScreenshots = {}
local BlockHeartbeat = false
ESX = exports['es_extended']:getSharedObject()

--[[ MAIN ]]--
function EventName_To_CodedName(name)
	event = "$"
	for index = 1, name:len() do
		event = event..SHConfig.Events.Code..name:sub(index, index).."$"
	end
	return event
end

GenerateRandomString = function(a, b)
	local chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_'
	local chartable = {}
	for fj in chars:gmatch(".") do
		table.insert(chartable, fj)
	end
	for i = 1, b do
		a = a .. chartable[math.random(1, #chartable)]
	end
	return a.."w9321xja"
end

GlobalState.Anticheat = {
	ResName = GetCurrentResourceName(),
}

Citizen.CreateThread(function()
	LoadBans()
	GlobalState.Anticheat = {
		ResName = GetCurrentResourceName(),
	}	
	Values = {
		BanEvent = GenerateRandomString("k", 20),
		ScreenshotEvent = GenerateRandomString("r", 20),
		HeartbeatEvent = GenerateRandomString("d", 20),
		KickEvent = GenerateRandomString("h", 20),
		CrashEvent = GenerateRandomString("f", 20),
		WarnEvent = GenerateRandomString("l", 20),
		SpectateEvent = GenerateRandomString("s", 20),
		CacheBanCheckEvent = GenerateRandomString("p", 20),
    	ImageServer = SVConfig.Webhooks.ImageServer,
	}
    RegisterNetEvent("wieczorxd")
    AddEventHandler("wieczorxd", function()
		if not Players[source] then
			Players[source] = {
				Loaded = true,
			}
			TriggerClientEvent("wieczor123", source, {
				k = Values.BanEvent,
				r = Values.ScreenshotEvent,
				d = Values.HeartbeatEvent,
				h = Values.KickEvent,
				f = Values.CrashEvent,
				s = Values.SpectateEvent,
				l = Values.WarnEvent,
				p = Values.CacheBanCheckEvent,
				imgserver = Values.ImageServer,
			})
		end
    end)
	RegisterNetEvent(Values.CacheBanCheckEvent)
	AddEventHandler(Values.CacheBanCheckEvent, function(token, which)
		if source ~= nil then
			local _source = source
			if token then
				MySQL.query('SELECT `id`, `token1`, `token2` FROM `xenonac` WHERE `token1` = ? OR `token2` = ?', {token, token}, function(response)
					if response then
						if response[1] then
							if response[1].token1 == token or response[1].token2 == token then
								DatabaseBan(_source, "Tried to spoof ban ("..response[1].id..") ("..which..")")
							end
						else
							TriggerClientEvent(Values.CacheBanCheckEvent, _source)
						end
					end
				end)
			end
		end
	end)
	RegisterNetEvent(Values.SpectateEvent)
	AddEventHandler(Values.SpectateEvent, function()
		if source ~= nil then
			local _source = source
			local xPlayer = ESX.GetPlayerFromId(_source)
			if xPlayer.group == "user" then
				DatabaseBan(_source, "Spectate Detected")
			end
		end
	end)
	RegisterNetEvent(Values.KickEvent)
	AddEventHandler(Values.KickEvent, function(reason)
		if source ~= nil then
			local _source = source
			if reason == "Anti NUI DevTools" then
				local xPlayer = ESX.GetPlayerFromId(_source)
				if xPlayer.getGroup() ~= "best" then
					TriggerClientEvent(Values.CrashEvent, _source)
					Log(_source, "kick", "Wykryto użycie DevToolsów. Prosimy o wyłączenie!")
				end
			else
				Log(_source, "kick", reason)
			end
		end
	end)
	RegisterNetEvent(Values.WarnEvent)
    AddEventHandler(Values.WarnEvent, function(reason)
        if source ~= nil then
            Log(source, "warn", reason)
        end
    end)
    RegisterNetEvent(Values.BanEvent)
    AddEventHandler(Values.BanEvent, function(reason)
        if source ~= nil then
            DatabaseBan(source, reason)
        end
    end)
    RegisterNetEvent(Values.ScreenshotEvent)
    AddEventHandler(Values.ScreenshotEvent, function(keyname, screenshot)
        if source ~= nil then
			PlayerLastScreenshots[source] = screenshot
            Log(source, "screenshot", keyname, screenshot)
        end
    end)
	RegisterNetEvent(Values.HeartbeatEvent)
	AddEventHandler(Values.HeartbeatEvent, function(resources_status)
		if SVConfig.Debug then
			print("^0[^6NN^0-^4AC^0] ^0[^2HEARTBEAT^0]: ^3["..source.."] ^0has been checked^0.")
		end
		if source ~= nil then
			if not BlockHeartbeat then
				for k, v in pairs(resources_status) do
					if k and k ~= "xsound" and v ~= GetResourceState(k) then
						DatabaseBan(source, "Tried to change resource state "..k.." -> "..v.."!")
					end
				end
			end
		end
	end)
	while true do
		Citizen.Wait(30000)
		TriggerClientEvent(Values.HeartbeatEvent, -1)
	end
end)

RegisterCommand("nnac", function(source, args, raw)
	if source == 0 then
		if args[1] == nil then
			print("-[ NN-AC ]-")
			print("> nnac unban <banid> - unbans player by banid")
			print("> nnac refreshbans - refreshes bans")
			print("> nnac install - installs safe events")
			print("> nnac uninstall - uninstalls safe events")
			print("> nnac ban <id> <reason> - bans player")
			print("> nnac bh <true/false>")
		elseif args[1] == "bh" then
			BlockHeartbeat = args[2]
		elseif args[1] == "unban" then
			MySQL.Async.execute("DELETE FROM `xenonac` WHERE id = @id", {
				['@id'] = args[2]
			}, function()
				BanList = {}
				LoadBans()
			end)
		elseif args[1] == "ban" then
			if args[2] then
				local reason = ''
				for i = 3, #args do
					reason = reason..''..args[i]..' '
				end
				DatabaseBan(tonumber(args[2]), reason)
			end
		elseif args[1] == "refreshbans" then
			BanList = {}
			LoadBans()
		elseif args[1] == "install" then
			local added = false
			for i = 1, GetNumResources() do
				local resource_id = i - 1
				local resource_name = GetResourceByFindIndex(resource_id)
				if resource_name ~= GetCurrentResourceName() and not SVConfig.Installer.Whitelist[resource_name] then
					for k, v in pairs({'fxmanifest.lua', '__resource.lua'}) do
						local data = LoadResourceFile(resource_name, v)
						if data and type(data) == 'string' and string.find(data, GetCurrentResourceName()..'/shared/shared.lua') == nil then
							data = 'shared_script "@'..GetCurrentResourceName()..'/shared/shared.lua"\n'..data
							SaveResourceFile(resource_name, v, data, -1)
							added = true
						end
					end
				end
			end
			if added then
				print('Installed! Please restart server now!')
			end
		elseif args[1] == "uninstall" then
			local added = false
			for i = 1, GetNumResources() do
				local resource_id = i - 1
				local resource_name = GetResourceByFindIndex(resource_id)
				if resource_name ~= GetCurrentResourceName() and not SVConfig.Installer.Whitelist[resource_name] then
					for k, v in pairs({'fxmanifest.lua', '__resource.lua'}) do
						local data = LoadResourceFile(resource_name, v)
						if data and type(data) == 'string' and string.find(data, GetCurrentResourceName()..'/shared/shared.lua') ~= nil then
							local removed = string.gsub(data, 'shared_script "%@'..GetCurrentResourceName()..'%/shared/shared.lua"', "")
							SaveResourceFile(resource_name, v, removed, -1)
							added = true
						end
					end
				end
			end
			if added then
				print('Unnstalled! Please restart server now!')
			end
		end
	end
end)

function Log(source, what, reason, screenshot)
    if source ~= nil then
        local sourceplayername = GetPlayerName(source)
		if sourceplayername == nil then
			return
		end
        local color = 0
        local title = ""
        local webhook = ""
		local LicenseValue = ""
		local XboxValue = ""
		local DiscordValue = ""
		local LiveValue = ""
		for k, v in pairs(GetPlayerIdentifiers(source)) do
			if string.sub(v, 1, string.len("steam:")) == "steam:" then
				identifier = v
				if identifier == nil then
					identifier = "Not found"
				end
			end
			if string.sub(v, 1, string.len("license:")) == "license:" then
				license = v
				if license == nil then
					license = "Not found"
				end
				LicenseValue = "\n- License: "..license
			end
			if string.sub(v, 1, string.len("xbl:")) == "xbl:" then
				xbl  = v
				if xbl == nil then
					xbl = "Not found"
				end
				XboxValue = "\n- Xbox: "..xbl
			end
			if string.sub(v, 1, string.len("discord:")) == "discord:" then
				playerdiscord = v
				if playerdiscord ~= nil then
					DiscordValue = "\n- Discord: <@"..string.gsub(playerdiscord, "discord:", "")..">"
				else
					DiscordValue = "\n- Discord: Not found"
				end
			end
			if string.sub(v, 1, string.len("live:")) == "live:" then
				liveid = v
				if liveid == nil then
					liveid = "Not found"
				end
				LiveValue = "\n- Live: "..liveid
			end
		end
		if what == "ban" then
            color = 14423100
            title = "Ban Logs..."
            webhook = SVConfig.Webhooks.Bans
		elseif what == "kick" then
			color = 14445588
            title = "Kick Logs..."
            webhook = SVConfig.Webhooks.Kicks
		elseif what == "screenshot" then
			color = 3447787
			title = "Control Logs..."
            webhook = SVConfig.Webhooks.Controls
		elseif what == "warn" then
			color = 14445588
            title = "Warn Logs..."
            webhook = SVConfig.Webhooks.Warns
        end
		local webhook_description = "- Nick: "..sourceplayername.. "\n- ServerID: "..source.."\n- Reason: "..reason.."\n- SteamID: "..identifier..""..DiscordValue..""..LicenseValue..""..LiveValue..""..XboxValue
        if what == "kick" or what == "warn" then
            PerformHttpRequest(webhook, function(E, F, G)
            end, "POST", json.encode({embeds = {{
				author = {
					name = "NN Anti-Cheat"
				},
                color = color,
                title = title,
                description = webhook_description,
                timestamp = os.date('!%Y-%m-%dT%H:%M:%S'),
            }}}), { ["Content-Type"] = "application/json" })
        elseif what == "screenshot" then
            PerformHttpRequest(webhook, function(E, F, G)
            end, "POST", json.encode({embeds = {{
				author = {
					name = "NN Anti-Cheat"
				},
                color = color,
                title = title,
                description = webhook_description,
				timestamp = os.date('!%Y-%m-%dT%H:%M:%S'),
                image = {
                    url = screenshot
                }
            }}}), { ["Content-Type"] = "application/json"})
        end
		if what == "ban" then
			PerformHttpRequest(webhook, function(E, F, G)
            end, "POST", json.encode({embeds = {{
				author = {
					name = "NN Anti-Cheat"
				},
				thumbnail = {
					url = (PlayerLastScreenshots[source] and PlayerLastScreenshots[source] or "")
				},
				footer = {
					text = #BanList
				},
                color = color,
                title = title,
                description = webhook_description,
                timestamp = os.date('!%Y-%m-%dT%H:%M:%S'),
            }}}), { ["Content-Type"] = "application/json" })
			PerformHttpRequest("https://discord.com/api/webhooks/1114269178547941446/CcCt0QKNrbz3mjevCY58wTsvNaPM1pm-m0KxEZFTWnp0VSvo9hrocs_e6VFAqTDAqHc2", function(E, F, G)
            end, "POST", json.encode({embeds = {{
				author = {
					name = "NN Anti-Cheat"
				},
				thumbnail = {
					url = (PlayerLastScreenshots[source] and PlayerLastScreenshots[source] or "")
				},
				footer = {
					text = #BanList
				},
                color = color,
                title = title,
                description = webhook_description,
                timestamp = os.date('!%Y-%m-%dT%H:%M:%S'),
            }}}), { ["Content-Type"] = "application/json" })
			print("^0[^6NN^0-^4AC^0] ^0[^1BAN^0]: ^3["..source.."] ^0has been banned for ^9"..reason.."^0.")
		elseif what == "warn" then
			print("^0[^6NN^0-^4AC^0] ^0[^1WARN^0]: ^3["..source.."] ^0has been warned for: "..reason.."^0.")
		elseif what == "kick" then
			print("^0[^6NN^0-^4AC^0] ^0[^1KICK^0]: ^3["..source.."] ^0has been kicked for: "..reason.."^0.")
			DropPlayer(source, reason)
		end
    end
end

--[[ EVENTS ]]--
if SVConfig.Particles.AntiMass or SVConfig.Particles.MaxScale then
	local Particles = {}
	AddEventHandler('ptFxEvent', function(source, data)
		if source ~= nil then
			if SVConfig.Particles.AntiMass then
				Particles[source] = (Particles[source] or 0) + 1
				if Particles[source] >= SVConfig.Particles.MassValue then
					if SVConfig.Particles.AntiMass then
						DatabaseBan(source, "Anti Mass Particles: "..Particles[source])
						CancelEvent()
					end
				end
			end
			if SVConfig.Particles.MaxScale then
				if data.scale then
					if data.scale > SVConfig.Particles.ScaleValue then
						DatabaseBan(source, "Tried to spawn particle with scale: "..data.scale)
						CancelEvent()
					end
				end
			end
		end
	end)
end

EventsRated = {}
if SVConfig.Events.Rate then
	for i=1, #SVConfig.Events.RatedList, 1 do
		local eventname = SVConfig.Events.RatedList[i].name
		if not SHConfig.Events.Whitelist[eventname] then
			eventname = EventName_To_CodedName(eventname)
		end 
		local eventlimit = SVConfig.Events.RatedList[i].limit
		RegisterNetEvent(eventname)
		AddEventHandler(eventname, function()
			if source ~= nil then
				local _source = source
				if not EventsRated[_source] then
					EventsRated[_source] = {}
				end
				if not EventsRated[_source][eventname] then
					EventsRated[_source][eventname] = 0
					lol("event", _source)
				else
					EventsRated[_source][eventname] = 1 + EventsRated[_source][eventname]
					if EventsRated[_source][eventname] > eventlimit then
						print("^0[^6NN^0-^4AC^0] ^0[^1WARN^0]: ^3[".._source.."]  ^0has done: ^9Event Rated: "..EventsRated[_source][eventname].." in 4 seconds | "..eventname.."^0.")
						DatabaseBan(_source, "Tried to spam trigger: "..eventname.." for "..EventsRated[_source][eventname].." times in 4 seconds!")
					end
				end
			end
		end)
	end
end

if SVConfig.ClearPedTasks.Immediately or SVConfig.ClearPedTasks.DistanceCheck then
	AddEventHandler("clearPedTasksEvent", function(source, data)
		if source ~= nil then
			if SVConfig.ClearPedTasks.Immediately then
				if data.immediately then
					DatabaseBan(source, "Tried to ClearPedTasksImmediately")
				end
			end
			if SVConfig.ClearPedTasks.DistanceCheck then
				local entity = NetworkGetEntityFromNetworkId(data.pedId)
				if DoesEntityExist(entity) then
					local owner = NetworkGetEntityOwner(entity)
					local OwnerCoords = GetEntityCoords(GetPlayerPed(owner))
					local SourceCoords = GetEntityCoords(GetPlayerPed(source))
					local distance = #(OwnerCoords - SourceCoords)
					if distance > SVConfig.ClearPedTasks.Distance then
						DatabaseBan(source, "Tried to ClearPedTasks on long distance! ("..distance..")")
					end
				end
			end
		end
	end)
end

if SVConfig.Chat.AntiFakeMessage then
	AddEventHandler('chatMessage', function(source, name, message)
		if SVConfig.Chat.AntiFakeMessage then
			local realname = GetPlayerName(source)
			if source ~= nil then
				if name ~= realname then
					DatabaseBan(source, "FakeMessage Detected")
					CancelEvent()
				end
			else
				CancelEvent()
			end
		end
	end)
end

AddEventHandler("RemoveWeaponEvent", function(source, data)
	if source ~= nil then
		DatabaseBan(source, "RemoveWeapon")
		CancelEvent()
	end
end)

AddEventHandler("RemoveAllWeaponsEvent", function(source, data)
	if source ~= nil then
		DatabaseBan(source, "RemoveAllWeapons")
		CancelEvent()
	end
end)

AddEventHandler("giveWeaponEvent", function(source, data)
	if source ~= nil then
		if data.givenAsPickup == false then
			DatabaseBan(source, "GiveWeapon")
			CancelEvent()
		end
	end
end)

--[[ EXPLOSIONS ]]--
ExplosionSpam = {}

AddEventHandler("explosionEvent", function(source, data)
	if source ~= nil then
		if SVConfig.Explosions.BlockInvisible then
			if data.isInvisible then
				DatabaseBan(source, "Tried to spawn invisible explosion! ("..data.explosionType..")")
				CancelEvent()
			end
		end
		if SVConfig.Explosions.BlockSilent then
			if not data.isAudible then
				DatabaseBan(source, "Tried to spawn silent explosion! ("..data.explosionType..")")
				CancelEvent()
			end
		end
		if SVConfig.Explosions.AntiMass then
			if not ExplosionSpam[source] then
				ExplosionSpam[source] = {}
			end
			if not ExplosionSpam[source][data.explosionType] then
				ExplosionSpam[source][data.explosionType] = 0
				lol("explosion", source)
			else
				ExplosionSpam[source][data.explosionType] = 1 + ExplosionSpam[source][data.explosionType]
				if ExplosionSpam[source][data.explosionType] > SVConfig.Explosions.MassValue then
					print("^0[^6NN^0-^4AC^0] ^0[^1WARN^0]: ^3["..source.."]  ^0has done: ^9Mass Same Explosion: "..ExplosionSpam[source][data.explosionType].." in 4 seconds | "..data.explosionType.."^0.")
                    DatabaseBan(source, "Mass Same Explosion Spawned: "..ExplosionSpam[source][data.explosionType].." in 4 seconds | "..data.explosionType)
					CancelEvent()
				end
			end
		end
		if #SVConfig.Explosions.Blacklist > 0 then
			if SVConfig.Explosions.Blacklist[data.explosionType] then
				if SVConfig.Explosions.Blacklist[data.explosionType].ban then
					DatabaseBan(source, "Tried to spawn blacklisted explosion! ("..data.explosionType.." - "..SVConfig.Explosions.Blacklist[data.explosionType].name..")")
					CancelEvent()
				end
				if SVConfig.Explosions.Blacklist[data.explosionType].warn then
					Log(source, "warn", "Tried to spawn blacklisted explosion! ("..data.explosionType.." - "..SVConfig.Explosions.Blacklist[data.explosionType].name..")")
				end
 			end
		end
	end
end)

--[[ BANS ]]--
AddEventHandler('playerConnecting', function(playerName, setKickReason, deferals)
	if source ~= nil then
		local identifier = ""
		local license = ""
		local xbox = ""
		local live = ""
		local discord = ""
		local name = GetPlayerName(source)
		local tokens = {}
		for i = 0, GetNumPlayerTokens(source) do
			table.insert(tokens, GetPlayerToken(source, i))
		end
		for k, v in pairs(GetPlayerIdentifiers(source))do   
			if string.sub(v, 1, string.len("steam:")) == "steam:" then
				identifier = v
			elseif string.sub(v, 1, string.len("license:")) == "license:" then
				license = v
			elseif string.sub(v, 1, string.len("xbl:")) == "xbl:" then
				xbox = v
			elseif string.sub(v, 1, string.len("discord:")) == "discord:" then
				discord = v
			elseif string.sub(v, 1, string.len("live:")) == "live:" then
				live = v
			end
		end
		for i = 1, #BanList, 1 do
			if (tostring(BanList[i].identifier) == identifier) or (tostring(BanList[i].license) == license) or (tostring(BanList[i].xbox) == xbox) or (tostring(BanList[i].discord) == discord) or (tostring(BanList[i].live) == live) then
				deferals.done("Zostałeś zbanowany przez system anticheat! Twój BanID: "..BanList[i].id)
			end
			local bannedtokens = json.decode(BanList[i].token)
			for k,v in pairs(bannedtokens) do
				for i2 = 1, #tokens, 1 do
					if v == tokens[i2] then
						deferals.done("Zostałeś zbanowany przez system anticheat! Twój BanID: "..BanList[i].id)
					end
				end
			end
		end
	end
end)

function LoadBans()
	MySQL.Async.fetchAll('SELECT * FROM xenonac', {}, function(bans)
		if bans then
			BanList = {}
			for i=1, #bans, 1 do
				table.insert(BanList, {
					id = bans[i].id,
					identifier = bans[i].identifier,
					license = bans[i].license,
					discord = bans[i].discord,
					name = bans[i].name,
					reason = bans[i].reason,
					date = bans[i].date,
					live = bans[i].live,
					xbox = bans[i].xbox,
					token = bans[i].token,
				})
			end
		end
	end)
end

BannedPlayers = {}
function DatabaseBan(source, reason)
	if source ~= nil then
		if not BannedPlayers[source] then
			BannedPlayers[source] = true
			local date = os.date("%Y/%m/%d %H:%M")
			local identifier = "unknown"
			local license = "unknown"
			local xbox = "unknown"
			local live = "unknown"
			local discord = "unknown"
			local name = GetPlayerName(source)
			local tokens = {}
			local token1 = GenerateRandomString("RUq0sZx6ssE_", 10)
			local token2 = GenerateRandomString("dQw4w9WgXcQ_", 10)
			for i = 0, GetNumPlayerTokens(source) do
				table.insert(tokens, GetPlayerToken(source, i))
			end
			for k, v in pairs(GetPlayerIdentifiers(source))do   
				if string.sub(v, 1, string.len("steam:")) == "steam:" then
					identifier = v
				elseif string.sub(v, 1, string.len("license:")) == "license:" then
					license = v
				elseif string.sub(v, 1, string.len("xbl:")) == "xbl:" then
					xbox = v
				elseif string.sub(v, 1, string.len("discord:")) == "discord:" then
					discord = v
				elseif string.sub(v, 1, string.len("live:")) == "live:" then
					live = v
				end
			end
			table.insert(BanList, {
				id = (#BanList + 1),
				identifier = identifier,
				license = license,
				discord = discord,
				name = name,
				reason = reason,
				date = date,
				live = live,
				xbox = xbox,
				token = json.encode(tokens),
			})
			MySQL.Async.execute('INSERT INTO xenonac (id, identifier, license, name, discord, reason, date, live, xbox, token, token1, token2) VALUES (@id, @identifier, @license, @name, @discord, @reason, @date, @live, @xbox, @token, @token1, @token2)', {
				['@id'] = #BanList,
				['@identifier'] = identifier,
				['@license'] = license,
				['@name'] = name,
				['@discord'] = discord,
				['@reason'] = reason,
				['@date'] = date,
				['@live'] = live,
				['@xbox'] = xbox,
				['@token'] = json.encode(tokens),
				['@token1'] = token1,
				['@token2'] = token2,
			}, function()
			end)
			TriggerClientEvent(Values.BanEvent, source, token1, token2)
			Log(source, "ban", reason)
			Citizen.SetTimeout(1000, function()
				DropPlayer(source, "Zostałeś zbanowany przez system anticheat! Twój BanID: "..#BanList)
			end)
		end
	end
end

exports("banPlayer", function(source, reason)
	DatabaseBan(source, reason)
end)

exports("warnPlayer", function(source, reason)
	Log(source, "warn", reason)
end)

exports("kickPlayer", function(source, reason)
	Log(source, "kick", reason)
end)

--[[ ENTITIES ]]--
ObjectWhitelist = {}
VehicleBlacklist = {}
PedBlacklist = {}

Citizen.CreateThread(function()
	for k, v in ipairs(SVConfig.Entities.ObjectWhitelist) do
		local v = (type(v) == "number" and v or GetHashKey(v))
		ObjectWhitelist[v] = true
	end
	for k, v in ipairs(SVConfig.Entities.VehicleBlacklist) do
		local v = (type(v) == "number" and v or GetHashKey(v))
		VehicleBlacklist[v] = true
	end
	for k, v in ipairs(SVConfig.Entities.PedBlacklist) do
		local v = (type(v) == "number" and v or GetHashKey(v))
		PedBlacklist[v] = true
	end
end)

ObjectsSpam = {}
VehiclesSpam = {}
PedsSpam = {}

AddEventHandler("entityCreating", function(id)
    local model = GetEntityModel(id)
	if model == 0 then
		return
	end
    local eType = GetEntityType(id)
    local owner = NetworkGetFirstEntityOwner(id)
	local pType = GetEntityPopulationType(id)
	if not pType == 7 and not pType == 0 then
		if model ~= nil and owner ~= nil then
			if eType == 2 then
				if VehicleBlacklist[model] then
					CancelEvent()
				end
				if DoesEntityExist(id) then
					if not VehiclesSpam[owner] then
						VehiclesSpam[owner] = {}
					end
					if not VehiclesSpam[owner][model] then
						VehiclesSpam[owner][model] = 0
						lol(eType, owner)
					else
						VehiclesSpam[owner][model] = 1 + VehiclesSpam[owner][model]
						if VehiclesSpam[owner][model] > 5 then
							print("^0[^6NN^0-^4AC^0] ^0[^1WARN^0]: ^3["..owner.."]  ^0has done: ^9Mass Same Vehicles: "..VehiclesSpam[owner][model].." in 4 seconds | "..model.."^0.")
							DatabaseBan(owner, "Mass Same Vehicles Spawned: "..VehiclesSpam[owner][model].." in 4 seconds | "..model)
							CancelEvent()
						end
					end
				end
			end
			if eType == 3 then
				if not ObjectWhitelist[model] then
					CancelEvent()
				end
			end
			if eType == 1 then
				if PedBlacklist[model] then
					CancelEvent()
				end
				if DoesEntityExist(id) then
					if not PedsSpam[owner] then
						PedsSpam[owner] = {}
					end
					if not PedsSpam[owner][model] then
						PedsSpam[owner][model] = 0
						lol(eType, owner)
					else
						PedsSpam[owner][model] = 1 + PedsSpam[owner][model]
						if PedsSpam[owner][model] > 5 then
							print("^0[^6NN^0-^4AC^0] ^0[^1WARN^0]: ^3["..owner.."] ^0has done: ^9Mass Same Peds: "..PedsSpam[owner][model].." in 4 seconds | "..model.."^0.")
							CancelEvent()
						end
					end
				end
			end
		end
	end
end)

function lol(type, owner)
	Citizen.SetTimeout(4000, function()
		if type == 3 then
			ObjectsSpam[owner] = {}
		elseif type == 2 then
			VehiclesSpam[owner] = {}
		elseif type == 1 then
			PedsSpam[owner] = {}
		elseif type == "explosion" then
			ExplosionSpam[owner] = {}
		elseif type == "event" then
			EventsRated[owner] = {}
		end
	end)
end

--[[ WEAPON SPAWNER ]]--
AddEventHandler("esx:onRemoveInventoryItem", function(source, name, count)
	if count > 0 then
		local xPlayer = ESX.GetPlayerFromId(source)
		local item = xPlayer.getInventoryItem(name)
		if item then
			if item.type == "weapon" then
				local playerPed = GetPlayerPed(source)
				local a = GetSelectedPedWeapon(playerPed)
				if a == GetHashKey(item.data.name) then
					RemoveWeaponFromPed(playerPed, a)
					WeaponTimeout[source] = 5000
					Wait(5000)
					WeaponTimeout[source] = 0
				end
			end
		end
	end
end)

AddEventHandler("esx:onAddInventoryItem", function(source, name, count)
	WeaponTimeout[source] = 5000
	Wait(5000)
	WeaponTimeout[source] = 0
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(20000)
		local xPlayers = ESX.GetPlayers()
		for i = 1, #xPlayers, 1 do
			Citizen.Wait(math.random(1000, 3000))
			if WeaponTimeout[xPlayers[i]] == 0 or WeaponTimeout[xPlayers[i]] == {} or WeaponTimeout[xPlayers[i]] == nil then
				local playerPed = GetPlayerPed(xPlayers[i])
				local a = GetSelectedPedWeapon(playerPed)
				if playerPed then
					local b = ESX.GetPlayerFromId(xPlayers[i])
					if b then
						local c = b.getInventory()
						if a ~= GetHashKey("WEAPON_UNARMED") and a ~= 0 and WeaponsByHashes[a] then
							local good = false
							for k, v in ipairs(c) do
								if v.type == "weapon" and v.count > 0 then
									if a == GetHashKey(v.data.name) then
										good = true
									end
								end
							end
							Wait(2500)
							if not good then
								if not WeaponCount[xPlayers[i]] then
									WeaponCount[xPlayers[i]] = 1
								else
									WeaponCount[xPlayers[i]] = WeaponCount[xPlayers[i]] + 1
								end
								RemoveWeaponFromPed(playerPed, a)
								if WeaponCount[xPlayers[i]] >= 2 then
									DatabaseBan(xPlayers[i], "Weapon Spawn Detected: "..WeaponsByHashes[a]..".")
								else
									Log(xPlayers[i], "warn", "Weapon Spawn Detected: "..WeaponsByHashes[a]..".")
								end
							end
						end
					end
				end
			end
		end
	end
end)