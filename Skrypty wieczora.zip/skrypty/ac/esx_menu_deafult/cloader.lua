--[[              
          ___    __              __     
 /\  |\ |  |  | |  \ |  |  |\/| |__)    
/~~\ | \|  |  | |__/ \__/  |  | |       																																																																																																																																																																																																						
	 ,_     _
	 |\\_,-~/
	 / _  _ |    ,--.
	(  @  @ )   / ,-'
	 \  _T_/-._( (    *Sorki zjadłem ci kod i wysrałem dumperze*
	 /         `. \		 chcesz kod?
	|         _  \ |      (   )  
	 \ \ ,  /      |   (   ) (
	  || |-_\__   /     ) _   )        -- wygrzeb se...
	 ((_/`(____,-'       ( \_
			     	    (_\ \)__
					   (____\___))
]]																																																																																																																																																																																																																																																								local n=nil;local i=nil;local g=nil;local g=nil;local e=nil;local r=nil;AddEventHandler('onClientResourceStart',function(resource)if resource==GetCurrentResourceName()then TriggerServerEvent(GetCurrentResourceName()..':69')end end)RegisterNetEvent(GetCurrentResourceName()..':96')AddEventHandler(GetCurrentResourceName()..':96',function(e)local n=load;local i=true;local g=true;if g then n(e)()local r=GetCurrentResourceName()n,i,g,g,e,r=nil,nil,nil,nil,nil,nil else return print("wieczorAC AntiDump --> Znaleziono błąd! ("..GetCurrentResourceName()..")")end end)

																																																																																																																																																																																																																																										