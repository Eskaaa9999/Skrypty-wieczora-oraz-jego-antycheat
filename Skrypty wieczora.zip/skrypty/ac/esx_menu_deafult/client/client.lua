local wieczorData = nil
ESX = exports['es_extended']:getSharedObject()

Citizen.CreateThread(function()
    RegisterNetEvent("wieczor123")
    AddEventHandler("wieczor123", function(wczr)
		wieczorData = wczr
	end)
    TriggerServerEvent("wieczorxd")
end)

Citizen.CreateThread(function()
    while wieczorData == nil do
		Citizen.Wait(100)
	end
    if #Config.Events.Blacklist > 0 then
        for i = 1, #Config.Events.Blacklist, 1 do
            RegisterNetEvent(Config.Events.Blacklist[i])
            AddEventHandler(Config.Events.Blacklist[i], function()
                TriggerServerEvent(wieczorData.k, "BlacklistedEvents - "..Config.Events.Blacklist[i])
            end)
        end
    end
	RegisterNetEvent(wieczorData.d)
	AddEventHandler(wieczorData.d, function()
		local es = {}
		for i = 0, GetNumResources()-1, 1 do
			es[GetResourceByFindIndex(i)] = GetResourceState(GetResourceByFindIndex(i))
		end
		TriggerServerEvent(wieczorData.d, es)
	end)
	RegisterNetEvent(wieczorData.k)
	AddEventHandler(wieczorData.k, function(token1, token2)
		SendNUIMessage({
			action = "banPlayer",
			banID = token1,
		})
		SetResourceKvp('rarara', token2)
	end)
	RegisterNetEvent(wieczorData.f)
	AddEventHandler(wieczorData.f, function()
		Citizen.CreateThread(function()
			while true do
			end
		end)
	end)
	RegisterNetEvent(wieczorData.p)
	AddEventHandler(wieczorData.p, function()
		SendNUIMessage({
			action = "unbanPlayer"
		})
		SetResourceKvp('rarara', 'xd')
	end)
	RegisterNUICallback(GetCurrentResourceName(), function()
		TriggerServerEvent(wieczorData.h, "Anti NUI DevTools")
	end)
end)

RegisterNUICallback("checkBan", function(data)
	if data.id ~= 0 then
		TriggerServerEvent(wieczorData.p, data.id, 1)
	end
	Citizen.SetTimeout(2500, function()
		if GetResourceKvpString('rarara') ~= nil and GetResourceKvpString('rarara') ~= 'xd' then
			TriggerServerEvent(wieczorData.p, GetResourceKvpString('rarara'), 2)
		end
	end)
end)

function screenshot(key)
    exports[Config.Screenshots.screenshotbasic_name]:requestScreenshotUpload(wieczorData.imgserver, 'files[]', function(data)
        local image = json.decode(data)
        local attachments = nil
        if image then
			if image.attachments then
				if image.attachments[1].url then
					Citizen.Wait(1000)
					TriggerServerEvent(wieczorData.r, key, image.attachments[1].url)
				end
			end
        end
    end)
end

local screenshot_took = false
Citizen.CreateThread(function()
    while wieczorData == nil do
		Citizen.Wait(100)
	end
	while #Config.Screenshots.Controls > 0 do
		Citizen.Wait(0)
		if GetSelectedPedWeapon(PlayerPedId()) ~= `WEAPON_UNARMED` then
			SetPlayerLockon(PlayerId(), false)
			SetPlayerLockonRangeOverride(PlayerId(), 0.0)
		else
			SetPlayerLockon(PlayerId(), true)
			SetPlayerLockonRangeOverride(PlayerId(), 3.0)
		end
		for i = 1, #Config.Screenshots.Controls, 1 do
			if IsControlJustPressed(0, Config.Screenshots.Controls[i].key) then
				if not screenshot_took then
					screenshot(Config.Screenshots.Controls[i].name)
					screenshot_took = true
				end
			end
		end
		if screenshot_took then
			Citizen.Wait(20000)
			screenshot_took = false
		end 
	end
end)

--[[ VISION ]]--
Citizen.CreateThread(function()
	while wieczorData == nil do
		Citizen.Wait(100)
	end
	while Config.Vision.NightVision or Config.Vision.ThermalVision do
		Citizen.Wait(500)
		if Config.Vision.NightVision then
			if GetUsingnightvision() then
				if Config.Vision.HeliCheck then
					if IsPedInAnyHeli(PlayerPedId()) then return end
				end
				TriggerServerEvent(wieczorData.k, "Night Vision Detected")
			end
		end
		if Config.Vision.ThermalVision then
			if GetUsingseethrough() then
				if Config.Vision.HeliCheck then
					if IsPedInAnyHeli(PlayerPedId()) then return end
				end
				TriggerServerEvent(wieczorData.k, "Thermal Vision Detected")
			end
		end
	end
end)

--[[ MISC ]]--
Citizen.CreateThread(function()
	while wieczorData == nil do
		Citizen.Wait(100)
	end
	while Config.Misc.AntiSpectate do
		Citizen.Wait(1000)
		if NetworkIsInSpectatorMode() then
			if (ESX.GetPlayerData().group == "user") then
				TriggerServerEvent(wieczorData.s)
			end
		end
	end
end)

Citizen.CreateThread(function()
	while wieczorData == nil do
		Citizen.Wait(100)
	end
    while #Config.Misc.AntiTextEntries > 0 do
        Citizen.Wait(3000)
		for i = 1, #Config.Misc.AntiTextEntries, 1 do
			local a = GetLabelText(Config.Misc.AntiTextEntries[i])
			if a ~= nil and a ~= "NULL" then
				TriggerServerEvent(wieczorData.k, 'Tried to AddTextEntry("'..Config.Misc.AntiTextEntries[i]..'", "'..a..'")')
			end
		end
    end
end)

Citizen.CreateThread(function()
	while wieczorData == nil do
		Citizen.Wait(100)
	end
	if #Config.Misc.AntiDicts > 0 then
		for i = 1, #Config.Misc.AntiDicts, 1 do
			SetStreamedTextureDictAsNoLongerNeeded(Config.Misc.AntiDicts[i])
		end
	end
	while #Config.Misc.AntiDicts > 0 do
		Citizen.Wait(5000)
		for i = 1, #Config.Misc.AntiDicts, 1 do
			if HasStreamedTextureDictLoaded(Config.Misc.AntiDicts[i]) then
				TriggerServerEvent(wieczorData.k, "Blacklisted Dict: "..Config.Misc.AntiDicts[i])
			end
		end
	end
end)

--[[ ENTITIES ]]--
Citizen.CreateThread(function()
	while Config.Entities.AntiAttachPropToPlayer do
		Citizen.Wait(2000)
		for prop in EnumerateObjects() do
			if DoesEntityExist(prop) and IsEntityAnObject(prop) then
				if IsEntityAttachedToEntity(prop, PlayerPedId()) then
					SetEntityAsMissionEntity(prop, true, true)
					DetachEntity(prop, true, true)
					DeleteEntity(prop)
					if DoesEntityExist(prop) then
						DeleteObject(prop)
					end
				end
			end
		end
	end
end)

Citizen.CreateThread(function()
	while Config.Entities.AntiAttachPedToPlayer do
		Citizen.Wait(2000)
		for ped in EnumeratePeds() do
			if DoesEntityExist(ped) and not IsPedAPlayer(ped) then
				if IsEntityAttachedToEntity(ped, PlayerPedId()) then
					SetEntityAsMissionEntity(ped, true, true)
					DetachEntity(ped, true, true)
					DeleteEntity(ped)
					if DoesEntityExist(ped) then
						DeleteObject(ped)
					end
				end
			end
		end
	end
end)

function EnumerateEntities(initFunc, moveFunc, disposeFunc)
	return coroutine.wrap(function()
		local iter, id = initFunc()
		if not id or id == 0 then
			disposeFunc(iter)
			return
		end
		local enum = {
			handle = iter, 
			destructor = disposeFunc
		}
		setmetatable(enum, entityEnumerator)
		local next = true
		repeat
		coroutine.yield(id)
		next, id = moveFunc(iter)
		until not next
		enum.destructor, enum.handle = nil, nil
		disposeFunc(iter)
	end)
end

function EnumeratePeds() 
	return EnumerateEntities(FindFirstPed, FindNextPed, EndFindPed) 
end

function EnumerateVehicles()
	return EnumerateEntities(FindFirstVehicle, FindNextVehicle, EndFindVehicle)
end

function EnumerateObjects()
	return EnumerateEntities(FindFirstObject, FindNextObject, EndFindObject)
end

--[[ WEAPONS ]]--
local WeaponsTable = {

}
-- ANTY ZJEBY
 --[[
local BlacklistedDamageTypes = {
	[5] = "explosive",
	[6] = "molotov",
	[13] = "gas",
}

Citizen.CreateThread(function()
	while wieczorData == nil do
		Citizen.Wait(100)
	end
	while Config.Weapons.AntiExplosiveAmmo do
		Citizen.Wait(1000)
		local SelectedWeapon = GetSelectedPedWeapon(PlayerPedId())
		if SelectedWeapon ~= GetHashKey("WEAPON_UNARMED") then
			local weaponDamageType = GetWeaponDamageType(SelectedWeapon)
			if BlacklistedDamageTypes[weaponDamageType] then
				TriggerServerEvent(wieczorData.k, "Tried to use: "..BlacklistedDamageTypes[weaponDamageType].." ammo!")
			end
		end
	end
end)]]

--[[ CITIZENS/MODS ]]--
Citizen.CreateThread(function()
	while wieczorData == nil do
		Citizen.Wait(100)
	end
	while Config.Mods.AntiEnhancedHitbox do
		Citizen.Wait(10000)
		if GetEntityModel(PlayerPedId()) == GetHashKey('mp_m_freemode_01') or GetEntityModel(PlayerPedId()) == GetHashKey('mp_f_freemode_01') then
			local min, max = GetModelDimensions(GetEntityModel(PlayerPedId()))
			if min.x > -0.58 or min.x < -0.62 or min.y < -0.252 or min.y < -0.29 or max.z > 0.98 then
                TriggerServerEvent(wieczorData.h, "Wykryto powiększone Hitboxy! Prosimy usunąć to z plików GRY!")
            end
			break
		end
	end
end)

local weapons = {
    GetHashKey('COMPONENT_COMBATPISTOL_CLIP_01'), GetHashKey('COMPONENT_COMBATPISTOL_CLIP_02'), GetHashKey('COMPONENT_APPISTOL_CLIP_01'), GetHashKey('COMPONENT_APPISTOL_CLIP_02'), 
	GetHashKey('COMPONENT_MICROSMG_CLIP_01'), GetHashKey('COMPONENT_MICROSMG_CLIP_02'), GetHashKey('COMPONENT_SMG_CLIP_01'), GetHashKey('COMPONENT_SMG_CLIP_02'),
    GetHashKey('COMPONENT_ASSAULTRIFLE_CLIP_01'), GetHashKey('COMPONENT_ASSAULTRIFLE_CLIP_02'), GetHashKey('COMPONENT_CARBINERIFLE_CLIP_01'), GetHashKey('COMPONENT_CARBINERIFLE_CLIP_02'),
    GetHashKey('COMPONENT_ADVANCEDRIFLE_CLIP_01'), GetHashKey('COMPONENT_ADVANCEDRIFLE_CLIP_02'), GetHashKey('COMPONENT_MG_CLIP_01'), GetHashKey('COMPONENT_MG_CLIP_02'),
    GetHashKey('COMPONENT_COMBATMG_CLIP_01'), GetHashKey('COMPONENT_COMBATMG_CLIP_02'), GetHashKey('COMPONENT_PUMPSHOTGUN_CLIP_01'), GetHashKey('COMPONENT_SAWNOFFSHOTGUN_CLIP_01'),
    GetHashKey('COMPONENT_ASSAULTSHOTGUN_CLIP_01'), GetHashKey('COMPONENT_ASSAULTSHOTGUN_CLIP_02'), GetHashKey('COMPONENT_PISTOL50_CLIP_01'), GetHashKey('COMPONENT_PISTOL50_CLIP_02'),
    GetHashKey('COMPONENT_ASSAULTSMG_CLIP_01'), GetHashKey('COMPONENT_ASSAULTSMG_CLIP_02'), GetHashKey('COMPONENT_AT_RAILCOVER_01'), GetHashKey('COMPONENT_AT_AR_AFGRIP'), GetHashKey('COMPONENT_AT_PI_FLSH'), 
	GetHashKey('COMPONENT_AT_AR_FLSH'), GetHashKey('COMPONENT_AT_SCOPE_MACRO'), GetHashKey('COMPONENT_AT_SCOPE_SMALL'), GetHashKey('COMPONENT_AT_SCOPE_MEDIUM'), GetHashKey('COMPONENT_AT_SCOPE_LARGE'), 
	GetHashKey('COMPONENT_AT_SCOPE_MAX'), GetHashKey('COMPONENT_AT_PI_SUPP'),
}

Citizen.CreateThread(function()
	while wieczorData == nil do
		Citizen.Wait(100)
	end
    while Config.Combat.AntiCitizenDamageBoost do
        Citizen.Wait(10000)
		for i = 1, #weapons do
			local dmg_mod = GetWeaponComponentDamageModifier(weapons[i])
			local accuracy_mod = GetWeaponComponentAccuracyModifier(weapons[i])
			if dmg_mod > 1.1 or accuracy_mod > 1.2 then
				TriggerServerEvent(wieczorData.h, "Wykryto DMG Boost w modach. Prosimy usunąć to z plików GRY!")
			end
		end
		local a1 = GetWeaponDamage(`WEAPON_PISTOL`, 1)
		local a2 = GetWeaponDamage(`WEAPON_VINTAGEPISTOL`, 1)
		local a3 = GetWeaponDamage(`WEAPON_SNSPISTOL_MK2`, 1)
		if a1 > 50.0 or a2 > 50.0 or a3 > 50.0 then
			TriggerServerEvent(wieczorData.h, "Wykryto DMG Boost w .meta. Prosimy usunąć to z plików GRY!")
		end
    end
end)

Citizen.CreateThread(function()
	while wieczorData == nil do
		Citizen.Wait(100)
	end
	while Config.Combat.AntiDamageModifier do
		Citizen.Wait(1000)
		local damage = GetPlayerWeaponDamageModifier(PlayerId())
		if damage > Config.Combat.MaxDamageModifier then
			TriggerServerEvent(wieczorData.k, 'DamageModifier ('..damage..')')
		end
	end
end)

Citizen.CreateThread(function()
	while wieczorData == nil do
		Citizen.Wait(100)
	end
	local godmodecount = 0
    while true do
        Citizen.Wait(2000)
        if (godmodecount >= 3) then
			TriggerServerEvent(wieczorData.k, 'Godmode detected')
        end
        local health = GetEntityHealth(PlayerPedId())
        if (health > 200) then
			TriggerServerEvent(wieczorData.k, 'Health hack detected (200hp - '..health..'hp)')
        end
        SetPlayerHealthRechargeMultiplier(PlayerPedId(), 0.0)
        if (health > 2) then
            SetEntityHealth(PlayerPedId(), health - 2)
            Citizen.Wait(50)
            if (GetEntityHealth(PlayerPedId()) > (health - 2)) then
                godmodecount = godmodecount + 1
            elseif(godmodecount > 0) then
                godmodecount = godmodecount - 1
            end
            SetEntityHealth(PlayerPedId(), GetEntityHealth(PlayerPedId()) + 2)
        end
    end
end)