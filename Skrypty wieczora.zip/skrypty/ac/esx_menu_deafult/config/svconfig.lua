SVConfig = {}
SVConfig.Debug = false

SVConfig.Webhooks = {
    Bans = "https://discord.com/api/webhooks/1069977482238894102/3MgV-zWkZsF4gbfOcATYS2fzZgcwR2_m1eUrelNEE2gbxYQ_AR_FX7dLH5SskS9r8TnF",
    Controls = "https://discord.com/api/webhooks/1069977701550669905/p3OwnLZRXsoNa6Izjq1Ei5kONSI-TS3xNUSvVfMMZu1EhnmQ32RFyBoh52lXW4HTES2X",
    Kicks = "https://discord.com/api/webhooks/1069977587033571418/-lLuVcbd-hrpDJsE_tdknnVUBX6E0i91kxVPm-W1CBNLx8q08UwPK49VPCKnV8sUmtF9",
    Warns = "https://discord.com/api/webhooks/1076608454313119754/tYWzv-Xrfj2QF8OQfirS340_BZnw6UXg-VgfFWgGW0Hu__-2k_Psd44-z5VfeTbd1jJw",
    ImageServer = "https://discord.com/api/webhooks/1069977653928525915/2wH-7o1JvcEB5IEens_jCVKQMbdKQa5m9w85QrVz-1Gfmt72-GN6kOsmhEDi3IHOdjGY",
}

SVConfig.Installer = {
    Whitelist = {
        ['monitor'] = true,
        ['sessionmanager'] = true,
        ['spawnmanager'] = true,
        -- YOURS
        ['Cityhall'] = true,
        ['Court_House'] = true,
        ['desert_mansion'] = true,
        ['vinewood_hills_mansion'] = true,
        ['21MODERNMANSION_5M'] = true,
        ['cfx-gabz-davispd'] = true,
        ['cfx-gabz-mapdata2'] = true,
        ['cfx-gabz-pdprops'] = true,
        ['forest_mansion'] = true,
        ['gabz_mrpd'] = true,
        ['mafiahotel13'] = true,
        ['Mecanica'] = true,
        ['xenon_maps'] = true,
        ['xenon_limitki'] = true,
        ['sivekm3cs'] = true,
        ['animowane'] = true,
        ['animoweanev2'] = true,
        ['c63zz'] = true,
        ['carssfly'] = true,
        ['dl_mh3'] = true,
        ['dzwiekifurek'] = true,
        ['gokuJT'] = true,
        ['lbperfs'] = true,
        ['maybachprint'] = true,
        ['mini'] = true,
        ['oycm4g82'] = true,
        ['rs3hyc'] = true,
        ['SASP'] = true,
        ['stomcio_bmwm3bpd'] = true,
        ['wheels'] = true,
        ['wieczorCars'] = true,
        ['xenon_vehicles'] = true,
        ['vane_maps'] = true,
        ['rfc_los_santos_customs'] = true,
        ['cfx-gabz-yachts'] = true,
        ['cfx-gabz-vbmarket'] = true,
        ['cfx-gabz-suburban'] = true,
        ['cfx-gabz-prison'] = true,
        ['cfx-gabz-pizzeria'] = true,
        ['cfx-gabz-pillbox'] = true,
        ['cfx-gabz-pdm'] = true,
        ['cfx-gabz-parkranger'] = true,
        ['cfx-gabz-paletobank'] = true,
        ['cfx-gabz-mrpd'] = true,
        ['cfx-gabz-mapdata'] = true,
        ['cfx-gabz-lscustoms'] = true,
        ['cfx-gabz-fleeca'] = true,
        ['cfx-gabz-diner'] = true,
        ['cfx-gabz-davispd'] = true,
        ['cfx-gabz-catcafe'] = true,
        ['cfx-gabz-binco'] = true,
        ['cfx-gabz-bennys'] = true,
        ['cfx-gabz-barber'] = true,
        ['cfx-gabz-ammunation'] = true,
        ['cfx-gabz-247'] = true,
    }
}

SVConfig.Events = {
    Blacklist = {
        'HCheat:TempDisableDetection', 'BsCuff:Cuff696999', 'adminmenu:allowall', 'antilynx8r4a:anticheat', 'antilynxr4:detect', 'ynx8:anticheat', 'lynx8:anticheat', 'hentailover:xdlol', 'antilynx8:anticheat', 
        'antilynxr6:detection', 'FAC:EzExec', 'h:xd', 'redst0nia:checking', 'esx-qalle-hunting:sell',
    },
    Rate = true,
    Timer = 4,
    RatedList = {
        {name = "asjkghfjhksafhjkasf:addContact", limit = 10},
        {name = "gcphone410255309243843843582193100974:sendMessage", limit = 10},
    },
}

SVConfig.Chat = {
    AntiFakeMessage = true,
}

SVConfig.Particles = {
    AntiMass = true,
    MassValue = 3,
    MaxScale = true,
    ScaleValue = 10,
}

SVConfig.ClearPedTasks = {
    DistanceCheck = true,
    Distance = 10,
    Immediately = false,
}

SVConfig.Explosions = {
    BlockInvisible = true,
    BlockSilent = true,
    AntiMass = false,
    MassValue = 5,
    Blacklist = {
        [0] = { name = "Grenade", ban = true, warn = false },
        [1] = { name = "GrenadeLauncher", ban = true, warn = false },
        [2] = { name = "Molotov", ban = false, warn = true },
        [3] = { name = "Rocket", ban = false, warn = true },
        [4] = { name = "TankShell", ban = false, warn = true },
        [5] = { name = "Hi_Octane", ban = false, warn = false },
        [6] = { name = "Car", ban = false, warn = false },
        [7] = { name = "Plance", ban = false, warn = false },
        [8] = { name = "Petrol Pump", ban = false, warn = false },
        [9] = { name = "Bike", ban = false, warn = false },
        [10] = { name = "Dir_Steam", ban = false, warn = false },
        [11] = { name = "Dir_Flame", ban = false, warn = false },
        [12] = { name = "Dir_Water_Hydrant", ban = false, warn = false },
        [13] = { name = "Dir_Gas_Canister", ban = false, warn = false },
        [14] = { name = "Boat", ban = false, warn = false },
        [15] = { name = "Ship_Destroy", ban = false, warn = false },
        [16] = { name = "Truck", ban = false, warn = false },
        [17] = { name = "Bullet", ban = false, warn = true },
        [18] = { name = "SmokeGrenadeLauncher", ban = true, warn = false },
        [19] = { name = "SmokeGrenade", ban = false, warn = false },
        [20] = { name = "BZGAS", ban = false, warn = false },
        [21] = { name = "Flare", ban = false, warn = false },
        [22] = { name = "Gas_Canister", ban = false, warn = false },
        [23] = { name = "Extinguisher", ban = false, warn = false },
        [24] = { name = "Programmablear", ban = false, warn = false },
        [25] = { name = "Train", ban = false, warn = false },
        [26] = { name = "Barrel", ban = false, warn = false },
        [27] = { name = "PROPANE", ban = false, warn = false },
        [28] = { name = "Blimp", ban = false, warn = false },
        [29] = { name = "Dir_Flame_Explode", ban = false, warn = false },
        [30] = { name = "Tanker", ban = false, warn = false },
        [31] = { name = "PlaneRocket", ban = false, warn = true },
        [32] = { name = "VehicleBullet", ban = false, warn = false },
        [33] = { name = "Gas_Tank", ban = false, warn = true },
        [34] = { name = "FireWork", ban = false, warn = false },
        [35] = { name = "SnowBall", ban = false, warn = false },
        [36] = { name = "ProxMine", ban = true, warn = false },
        [37] = { name = "Valkyrie_Cannon", ban = true, warn = false },
    },
}

SVConfig.Entities = {
    ObjectWhitelist = {
        -1038739674, 'p_till_01_s', 'prop_poly_bag_01', 'p_v_43_safe_s', 'prop_drug_package_02', 'prop_tool_broom', 'p_ld_stinger_s', 'prop_monitor_w_large', 'prop_rub_table_01', 'xm_base_cia_server_01', 
        'v_corp_servercln2', 'prop_barrier_work05', 'hei_prop_cash_crate_half_full', 'prop_boxpile_07d', 'prop_roadcone02a', 'prop_wheelchair_01', 'prop_ballistic_shield', 'prop_cs_phone_01', 'prop_money_bag_01',
        'prop_cs_spray_can', 'w_ar_carbinerifle', 'w_sg_pumpshotgun', 'prop_v_cam_01', 'p_ing_microphonel_01', 'apa_mp_apa_yacht_jacuzzi_ripple1', 'xm_prop_x17_l_door_glass_01', 'xm_prop_x17_l_glass_01',
        'xm_prop_x17_l_glass_02', 'xm_prop_x17_l_glass_03', 'prop_cs_burger_01', 'prop_peanut_bowl_01', 'v_ret_ml_chips2', 'prop_energy_drink', 'prop_cs_beer_bot_02', 'prop_cs_beer_bot_40oz_02', 'p_whiskey_bottle_s',
        'prop_sh_tall_glass', 'ba_prop_battle_shot_glass_01', 'prop_mojito', 'prop_rum_bottle', 'v_res_fh_fruitbowl', 'ng_proc_sodacan_01b', 'prop_ld_flow_bottle', 'vw_prop_vw_champ_closed', 'prop_cs_coke_line',
        'prop_weed_bottle', 'prop_cigar_03', 'p_amb_joint_01', 'prop_tool_pickaxe', 'prop_cs_remote_01', 'prop_cs_hand_radio', 'prop_v_bmike_01', 'hei_p_m_bag_var22_arm_s', 'hei_prop_heist_thermite', 
        'hei_prop_hst_laptop', 'hei_prop_heist_card_hack_02', 'p_ld_id_card_01', 'hei_prop_heist_cash_pile', 'prop_amb_phone', 'ng_proc_sodabot_01a', 'ng_proc_box_01a', 'ng_proc_food_burg01a', 
        'ba_prop_battle_glowstick_01', 'ba_prop_battle_hobby_horse', 'prop_rub_planks_01', 'prop_log_01', 'p_amb_brolly_01', 'prop_notepad_01', 'prop_pencil_01', 'hei_prop_heist_box', 'prop_single_rose', 
        'prop_cs_ciggy_01', 'hei_heist_sh_bong_01', 'prop_ld_suitcase_01', 'prop_security_case_01', 'prop_police_id_board', 'p_amb_coffeecup_01', 'prop_drink_whisky', 'prop_amb_beer_bottle', 'prop_plastic_cup_02',
        'prop_amb_donut', 'prop_sandwich_01', 'prop_food_mustard', 'prop_rolled_sock_02', 'prop_ecola_can', 'prop_boombox_01', 'prop_choc_ego', 'prop_drink_redwine', 'prop_champ_flute', 'prop_drink_champ', 
        'prop_cigar_02', 'prop_cigar_01', 'prop_acc_guitar_01', 'prop_el_guitar_01', 'prop_el_guitar_03', 'prop_novel_01', 'prop_snow_flower_02', 'v_ilev_mr_rasberryclean', 'p_michael_backpack_s', 'p_amb_clipboard_01',
        'prop_tourist_map_01', 'prop_beggers_sign_03', 'prop_anim_cash_pile_01', 'prop_pap_camera_01', 'ba_prop_battle_champ_open', 'p_cs_joint_02', 'prop_amb_ciggy_01', 'prop_ld_case_01', 'prop_cs_tablet', 
        'prop_npc_phone_02', 'prop_sponge_01', 'prop_cone_float_1', 'prop_cctv_cam_01a_2', 'prop_cctv_cam_01b_2', 'prop_cctv_cam_02a_2', 'prop_cctv_cam_03a_2', 'prop_cctv_cam_04a_2', 'prop_cctv_cam_04b_2', 
        'prop_cctv_cam_04c_2', 'prop_cctv_cam_05a_2', 'prop_cctv_cam_06a_2', 'prop_cctv_cam_07a_2', 'prop_box_wood02a_pu', 'p_cargo_chute_s', 'ex_prop_adv_case_sm', 269934519, 2007413986, 881130828, 769923921, 2714348429
    },
    VehicleBlacklist = {
        "submarine", "tug", "blimp2", "blimp", "vestra", "vigilante", "hydra", "buzzard", "deluxo", "freight", "valkyrie", "marshall", "technical2", "avenger", "akula", "apc", "barrage", "caracara", "cargobob", "jet",
        "chernobog", "cargoplane", "hunter", "insurgent", "starling", "lazer", "bombushka", "savage", "rhino", "khanjali", "tractor", "dump", "freight", "dune2", "tanker", "ruiner2", "blaze", "oppressor", "oppressor2", "ambulance", 
        "imperator", "imperator2", "imperator3", "issi4", "issi5", "issi6", "monster3", "monster4", "monster5", "scarab", "scarab2", "scarab3", "slamvan4", "slamvan5", "slamvan6", "zr380", "zr3802", "zr3803", "DOMINATOR6",
    },
    PedBlacklist = {
        "a_c_dolphin", "a_c_killerwhale",  "a_c_sharktiger", "a_c_humpback", "mp_m_niko_01", "a_m_m_tramp_01", "hc_gunman", "ig_johnnyklebitz", "u_m_y_staggrm_01", 'mp_m_marston_01', 'u_m_y_prisoner_01', 'ig_wade',
        'cs_orleans', 's_m_y_swat_01', 'mp_m_freemode_01', 'mp_f_freemode_01', 'a_m_y_skater_01', 'u_m_y_pogo_01', "player_zero", "player_one", "player_two", "u_m_m_streetart_01", "u_m_m_jesus_01", "u_m_y_babyd",
        "u_m_y_rsranger_01", "u_m_y_zombie_01", "u_m_y_pogo_0", "s_m_y_clown_01", "s_m_m_movspace_01", "mp_f_cocaine_01", "g_m_y_famca_01", "g_m_y_ballasout_01", "g_m_y_famfor_01", "g_m_y_ballaeast_01", "a_c_chimp", 
        "a_m_m_acult_01", "a_m_y_skater_02", "u_m_y_juggernaut_01"
    },
}
